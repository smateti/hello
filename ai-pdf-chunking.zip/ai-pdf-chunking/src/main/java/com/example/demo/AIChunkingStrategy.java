package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;

/**
 * Chunking Strategy Interface
 */
public interface AIChunkingStrategy {
    List<ChunkResult> chunkDocument(Document document, ChunkingParameters parameters);
    String getStrategyName();
    ChunkingMetrics getMetrics();
}

