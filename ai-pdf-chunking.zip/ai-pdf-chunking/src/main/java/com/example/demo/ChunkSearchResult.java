package com.example.demo;

import java.util.List;
import java.util.Map;

/**
 * Chunk Search Result DTO
 */
public class ChunkSearchResult {
    private Long id;
    private String documentId;
    private Integer chunkIndex;
    private String content;
    private String summary;
    private String keywords;
    private String topicCategory;
    private Double confidence;
    private String sectionTitle;

    public ChunkSearchResult(Long id, String documentId, Integer chunkIndex, String content,
                           String summary, String keywords, String topicCategory, 
                           Double confidence, String sectionTitle) {
        this.id = id;
        this.documentId = documentId;
        this.chunkIndex = chunkIndex;
        this.content = content;
        this.summary = summary;
        this.keywords = keywords;
        this.topicCategory = topicCategory;
        this.confidence = confidence;
        this.sectionTitle = sectionTitle;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDocumentId() { return documentId; }
    public void setDocumentId(String documentId) { this.documentId = documentId; }

    public Integer getChunkIndex() { return chunkIndex; }
    public void setChunkIndex(Integer chunkIndex) { this.chunkIndex = chunkIndex; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }

    public String getKeywords() { return keywords; }
    public void setKeywords(String keywords) { this.keywords = keywords; }

    public String getTopicCategory() { return topicCategory; }
    public void setTopicCategory(String topicCategory) { this.topicCategory = topicCategory; }

    public Double getConfidence() { return confidence; }
    public void setConfidence(Double confidence) { this.confidence = confidence; }

    public String getSectionTitle() { return sectionTitle; }
    public void setSectionTitle(String sectionTitle) { this.sectionTitle = sectionTitle; }
}