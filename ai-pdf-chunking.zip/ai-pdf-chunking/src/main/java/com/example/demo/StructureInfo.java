package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StructureInfo {
    private String documentType = "unknown";
    private List<SectionInfo> sections = new ArrayList<>();
    private boolean hasToc = false;
    private List<String> formattingPatterns = new ArrayList<>();

    // Getters and Setters
    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public List<SectionInfo> getSections() {
        return sections;
    }

    public void setSections(List<SectionInfo> sections) {
        this.sections = sections;
    }

    public boolean isHasToc() {
        return hasToc;
    }

    public void setHasToc(boolean hasToc) {
        this.hasToc = hasToc;
    }

    public List<String> getFormattingPatterns() {
        return formattingPatterns;
    }

    public void setFormattingPatterns(List<String> formattingPatterns) {
        this.formattingPatterns = formattingPatterns;
    }
}