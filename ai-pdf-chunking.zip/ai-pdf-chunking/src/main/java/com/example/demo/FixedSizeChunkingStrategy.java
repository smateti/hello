package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;


@Component
public class FixedSizeChunkingStrategy implements AIChunkingStrategy {
    
    private ChunkingMetrics metrics;
    
    @Override
    public List<ChunkResult> chunkDocument(Document document, ChunkingParameters parameters) {
        long startTime = System.currentTimeMillis();
        List<ChunkResult> chunks = new ArrayList<>();
        
        String content = document.getText();
        int maxSize = parameters.getMaxChunkSize();
        int overlap = parameters.getOverlap();
        
        int start = 0;
        int chunkIndex = 0;
        
        while (start < content.length()) {
            int end = Math.min(start + maxSize, content.length());
            
            // Adjust end to avoid cutting words
            if (end < content.length()) {
                int lastSpace = content.lastIndexOf(' ', end);
                if (lastSpace > start) {
                    end = lastSpace;
                }
            }
            
            String chunkContent = content.substring(start, end);
            
            // Skip if chunk is too small
            if (chunkContent.length() < parameters.getMinChunkSize() && end < content.length()) {
                start = Math.max(start + 1, end - overlap);
                continue;
            }
            
            Map<String, Object> metadata = createMetadata(document, chunkIndex, start, end);
            chunks.add(new ChunkResult(chunkContent, metadata, start, end, 1.0));
            
            start = Math.max(start + 1, end - overlap);
            chunkIndex++;
        }
        
        this.metrics = calculateMetrics(chunks, content, System.currentTimeMillis() - startTime);
        return chunks;
    }
    
    @Override
    public String getStrategyName() {
        return "FixedSizeChunking";
    }
    
    @Override
    public ChunkingMetrics getMetrics() {
        return metrics;
    }
    
    private Map<String, Object> createMetadata(Document document, int chunkIndex, int start, int end) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("chunkIndex", chunkIndex);
        metadata.put("startPosition", start);
        metadata.put("endPosition", end);
        metadata.put("strategy", getStrategyName());
        metadata.put("originalDocumentId", document.getId());
        return metadata;
    }
    
    private ChunkingMetrics calculateMetrics(List<ChunkResult> chunks, String originalContent, long processingTime) {
        ChunkingMetrics metrics = new ChunkingMetrics();
        metrics.setTotalChunks(chunks.size());
        metrics.setProcessingTime(processingTime);
        metrics.setTotalCharacters(originalContent.length());
        
        if (!chunks.isEmpty()) {
            double avgSize = chunks.stream().mapToInt(c -> c.getContent().length()).average().orElse(0);
            metrics.setAverageChunkSize(avgSize);
        }
        
        return metrics;
    }
}