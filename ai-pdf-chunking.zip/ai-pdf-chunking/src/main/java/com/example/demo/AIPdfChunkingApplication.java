package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main Application Class for AI PDF Chunking Service
 */
@SpringBootApplication
@EnableJpaRepositories
@EnableScheduling
public class AIPdfChunkingApplication {

    public static void main(String[] args) {
        SpringApplication.run(AIPdfChunkingApplication.class, args);
    }
}