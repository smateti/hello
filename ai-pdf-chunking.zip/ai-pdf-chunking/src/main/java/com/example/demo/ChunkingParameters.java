package com.example.demo;

import java.util.ArrayList;
import java.util.List;

/**
 * Chunking Parameters Class
 */
public class ChunkingParameters {
    private int chunkSize = 1000;
    private int overlap = 200;
    private int minChunkSize = 100;
    private int maxChunkSize = 2000;
    private double similarityThreshold = 0.7;
    private boolean preserveStructure = true;
    private String embeddingModel = "nomic-embed-text";
    private List<String> stopWords = new ArrayList<>();
    private String[] separators = {"\n\n", "\n", ".", "!", "?", " "};
    private boolean includeMetadata = true;
    
    // Getters and Setters
    public int getChunkSize() {
        return chunkSize;
    }

    public void setChunkSize(int chunkSize) {
        this.chunkSize = chunkSize;
    }

    public int getOverlap() {
        return overlap;
    }

    public void setOverlap(int overlap) {
        this.overlap = overlap;
    }

    public int getMinChunkSize() {
        return minChunkSize;
    }

    public void setMinChunkSize(int minChunkSize) {
        this.minChunkSize = minChunkSize;
    }

    public int getMaxChunkSize() {
        return maxChunkSize;
    }

    public void setMaxChunkSize(int maxChunkSize) {
        this.maxChunkSize = maxChunkSize;
    }

    public double getSimilarityThreshold() {
        return similarityThreshold;
    }

    public void setSimilarityThreshold(double similarityThreshold) {
        this.similarityThreshold = similarityThreshold;
    }

	public boolean isPreserveStructure() {
		return preserveStructure;
	}

	public void setPreserveStructure(boolean preserveStructure) {
		this.preserveStructure = preserveStructure;
	}

	public String getEmbeddingModel() {
		return embeddingModel;
	}

	public void setEmbeddingModel(String embeddingModel) {
		this.embeddingModel = embeddingModel;
	}

	public List<String> getStopWords() {
		return stopWords;
	}

	public void setStopWords(List<String> stopWords) {
		this.stopWords = stopWords;
	}

	public String[] getSeparators() {
		return separators;
	}

	public void setSeparators(String[] separators) {
		this.separators = separators;
	}

	public boolean isIncludeMetadata() {
		return includeMetadata;
	}

	public void setIncludeMetadata(boolean includeMetadata) {
		this.includeMetadata = includeMetadata;
	}

}