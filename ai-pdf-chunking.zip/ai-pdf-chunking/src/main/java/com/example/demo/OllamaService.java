package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Enhanced Ollama Service with HTTP Client
 */
@Service
public class OllamaService {
    
    private static final Logger logger = LoggerFactory.getLogger(OllamaService.class);
    
    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final String ollamaBaseUrl;
    
    public OllamaService(@Value("${ollama.base-url:http://localhost:11434}") String ollamaBaseUrl) {
        this.httpClient = new OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build();
        this.objectMapper = new ObjectMapper();
        this.ollamaBaseUrl = ollamaBaseUrl;
    }
    
    public List<Double> generateEmbedding(String text, String model) throws IOException {
        Map<String, Object> requestBody = Map.of(
            "model", model,
            "prompt", text
        );
        
        String json = objectMapper.writeValueAsString(requestBody);
        System.out.println(json);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        
        Request request = new Request.Builder()
            .url(ollamaBaseUrl + "/api/embeddings")
            .post(body)
            .build();
        
        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Embedding request failed: " + response.body().string());
            }
            
            String responseBody = response.body().string();
            Map<String, Object> result = objectMapper.readValue(responseBody, Map.class);
            
            @SuppressWarnings("unchecked")
            List<Double> embedding = (List<Double>) result.get("embedding");
            
            if (embedding == null || embedding.isEmpty()) {
                throw new IOException("No embedding returned from Ollama");
            }
            
            return embedding;
        }
    }
    
    public String generateChat(String prompt, String model) throws IOException {
        Map<String, Object> requestBody = Map.of(
            "model", model,
            "prompt", prompt,
            "stream", false
        );
        
        String json = objectMapper.writeValueAsString(requestBody);
        System.out.println(json);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        
        Request request = new Request.Builder()
            .url(ollamaBaseUrl + "/api/generate")
            .post(body)
            .build();
        
        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Chat request failed: " + response.body().string());
            }
            
            String responseBody = response.body().string();
            Map<String, Object> result = objectMapper.readValue(responseBody, Map.class);
            
            return (String) result.get("response");
        }
    }
    
    public boolean isModelAvailable(String model) {
        try {
            Request request = new Request.Builder()
                .url(ollamaBaseUrl + "/api/tags")
                .get()
                .build();
            
            try (Response response = httpClient.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    Map<String, Object> result = objectMapper.readValue(responseBody, Map.class);
                    
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> models = (List<Map<String, Object>>) result.get("models");
                    
                    return models.stream()
                        .anyMatch(m -> model.equals(m.get("name")));
                }
            }
        } catch (Exception e) {
            logger.warn("Failed to check model availability: {}", e.getMessage());
        }
        
        return false;
    }
    
    public List<String> getAvailableModels() {
        try {
            Request request = new Request.Builder()
                .url(ollamaBaseUrl + "/api/tags")
                .get()
                .build();
            
            try (Response response = httpClient.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    Map<String, Object> result = objectMapper.readValue(responseBody, Map.class);
                    
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> models = (List<Map<String, Object>>) result.get("models");
                    
                    return models.stream()
                        .map(m -> (String) m.get("name"))
                        .collect(Collectors.toList());
                }
            }
        } catch (Exception e) {
            logger.warn("Failed to get available models: {}", e.getMessage());
        }
        
        return Collections.emptyList();
    }
}