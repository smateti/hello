package com.example.demo;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Custom PDF Document Reader using Apache PDFBox
 * Compatible with PDFBox 3.0.x
 */
@Component
public class CustomPdfDocumentReader {
    
    private static final Logger logger = LoggerFactory.getLogger(CustomPdfDocumentReader.class);
    
    public List<Document> readPdf(MultipartFile file) throws IOException {
        return readPdf(file.getInputStream(), file.getOriginalFilename());
    }
    
    public List<Document> readPdf(InputStream inputStream, String filename) throws IOException {
        List<Document> documents = new ArrayList<>();
        
        // Convert InputStream to byte array for PDFBox 3.x compatibility
        byte[] pdfBytes = inputStreamToByteArray(inputStream);
        
        try (PDDocument pdDocument = Loader.loadPDF(pdfBytes)) {
            PDFTextStripper textStripper = new PDFTextStripper();
            
            // Extract text from all pages
            String fullText = textStripper.getText(pdDocument);
            
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("source", filename);
            metadata.put("total_pages", pdDocument.getNumberOfPages());
            metadata.put("extraction_date", LocalDateTime.now().toString());
            
            
            // Extract document info if available
            PDDocumentInformation info = pdDocument.getDocumentInformation();
            if (info != null) {
                if (info.getTitle() != null) metadata.put("title", info.getTitle());
                if (info.getAuthor() != null) metadata.put("author", info.getAuthor());
                if (info.getSubject() != null) metadata.put("subject", info.getSubject());
                if (info.getCreationDate() != null) metadata.put("creation_date", info.getCreationDate().toString());
            }
            
            documents.add(new Document(fullText, metadata));
            
            // Also extract page-by-page for better granularity
            for (int i = 1; i <= pdDocument.getNumberOfPages(); i++) {
                textStripper.setStartPage(i);
                textStripper.setEndPage(i);
                String pageText = textStripper.getText(pdDocument);
                
                Map<String, Object> pageMetadata = new HashMap<>(metadata);
                pageMetadata.put("page_number", i);
                pageMetadata.put("page_content_length", pageText.length());
                
                documents.add(new Document(pageText, pageMetadata));
            }
            
        } catch (Exception e) {
            logger.error("Error reading PDF: {}", e.getMessage(), e);
            throw new IOException("Failed to read PDF: " + e.getMessage(), e);
        }
        
        return documents;
    }
    
    public String extractTextOnly(MultipartFile file) throws IOException {
        byte[] pdfBytes = inputStreamToByteArray(file.getInputStream());
        
        try (PDDocument pdDocument = Loader.loadPDF(pdfBytes)) {
            PDFTextStripper textStripper = new PDFTextStripper();
            return textStripper.getText(pdDocument);
            
        } catch (Exception e) {
            logger.error("Error extracting text from PDF: {}", e.getMessage(), e);
            throw new IOException("Failed to extract text from PDF: " + e.getMessage(), e);
        }
    }
    
    public PdfMetadata extractMetadata(MultipartFile file) throws IOException {
        byte[] pdfBytes = inputStreamToByteArray(file.getInputStream());
        
        try (PDDocument pdDocument = Loader.loadPDF(pdfBytes)) {
            PdfMetadata pdfMetadata = new PdfMetadata();
            pdfMetadata.setPageCount(pdDocument.getNumberOfPages());
            pdfMetadata.setFileName(file.getOriginalFilename());
            pdfMetadata.setFileSize(file.getSize());
            
            PDDocumentInformation info = pdDocument.getDocumentInformation();
            if (info != null) {
                pdfMetadata.setTitle(info.getTitle());
                pdfMetadata.setAuthor(info.getAuthor());
                pdfMetadata.setSubject(info.getSubject());
                pdfMetadata.setKeywords(info.getKeywords());
                pdfMetadata.setCreator(info.getCreator());
                pdfMetadata.setProducer(info.getProducer());
                
                if (info.getCreationDate() != null) {
                    pdfMetadata.setCreationDate(info.getCreationDate().toInstant()
                        .atZone(ZoneId.systemDefault()).toLocalDateTime());
                }
                if (info.getModificationDate() != null) {
                    pdfMetadata.setModificationDate(info.getModificationDate().toInstant()
                        .atZone(ZoneId.systemDefault()).toLocalDateTime());
                }
            }
            
            return pdfMetadata;
            
        } catch (Exception e) {
            logger.error("Error extracting PDF metadata: {}", e.getMessage(), e);
            throw new IOException("Failed to extract PDF metadata: " + e.getMessage(), e);
        }
    }
    
    /**
     * Helper method to convert InputStream to byte array
     * This is needed for PDFBox 3.x compatibility
     */
    private byte[] inputStreamToByteArray(InputStream inputStream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int nRead;
        byte[] data = new byte[16384]; // 16KB buffer
        
        while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        
        return buffer.toByteArray();
    }
}