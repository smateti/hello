package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import jakarta.annotation.PostConstruct;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;

/**
 * GPU-aware configuration for AI processing
 */
@Configuration
public class GPUConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(GPUConfiguration.class);
    
    @Value("${ai.gpu.enabled:true}")
    private boolean gpuEnabled;
    
    @Value("${ai.processing.threads:#{T(java.lang.Runtime).getRuntime().availableProcessors()}}")
    private int processingThreads;
    
    @Value("${ai.batch.size.cpu:32}")
    private int cpuBatchSize;
    
    @Value("${ai.batch.size.gpu:128}")
    private int gpuBatchSize;
    
    @PostConstruct
    public void logConfiguration() {
        logger.info("GPU Configuration:");
        logger.info("  GPU Enabled: {}", gpuEnabled);
        logger.info("  Processing Threads: {}", processingThreads);
        logger.info("  CPU Batch Size: {}", cpuBatchSize);
        logger.info("  GPU Batch Size: {}", gpuBatchSize);
        logger.info("  Available Processors: {}", Runtime.getRuntime().availableProcessors());
        logger.info("  Max Memory: {} MB", Runtime.getRuntime().maxMemory() / 1024 / 1024);
    }
    
    @Bean
    @Primary
    public ExecutorService aiProcessingExecutor() {
        if (processingThreads > Runtime.getRuntime().availableProcessors()) {
            logger.info("Creating ForkJoinPool with {} threads for AI processing", processingThreads);
            return new ForkJoinPool(processingThreads);
        } else {
            logger.info("Creating FixedThreadPool with {} threads for AI processing", processingThreads);
            return Executors.newFixedThreadPool(processingThreads);
        }
    }
    
    @Bean
    public AIProcessingConfig aiProcessingConfig() {
        return new AIProcessingConfig(
            gpuEnabled,
            processingThreads,
            cpuBatchSize,
            gpuBatchSize
        );
    }
    
    /**
     * Configuration class for AI processing parameters
     */
    public static class AIProcessingConfig {
        private final boolean gpuEnabled;
        private final int processingThreads;
        private final int cpuBatchSize;
        private final int gpuBatchSize;
        
        public AIProcessingConfig(boolean gpuEnabled, int processingThreads, 
                                 int cpuBatchSize, int gpuBatchSize) {
            this.gpuEnabled = gpuEnabled;
            this.processingThreads = processingThreads;
            this.cpuBatchSize = cpuBatchSize;
            this.gpuBatchSize = gpuBatchSize;
        }
        
        public boolean isGpuEnabled() { return gpuEnabled; }
        public int getProcessingThreads() { return processingThreads; }
        public int getCpuBatchSize() { return cpuBatchSize; }
        public int getGpuBatchSize() { return gpuBatchSize; }
        
        public int getOptimalBatchSize(boolean hasGpu) {
            return hasGpu && gpuEnabled ? gpuBatchSize : cpuBatchSize;
        }
    }
}