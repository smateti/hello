package com.example.demo;

import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Custom Token Text Splitter for intelligent document chunking
 */
@Component
public class CustomTokenTextSplitter {
    
    private final int chunkSize;
    private final int chunkOverlap;
    private final int minChunkSize;
    private final int maxChunkSize;
    private final boolean preserveStructure;
    
    public CustomTokenTextSplitter() {
        this(1000, 200, 100, 2000, true);
    }
    
    public CustomTokenTextSplitter(int chunkSize, int chunkOverlap, int minChunkSize, 
                                  int maxChunkSize, boolean preserveStructure) {
        this.chunkSize = chunkSize;
        this.chunkOverlap = chunkOverlap;
        this.minChunkSize = minChunkSize;
        this.maxChunkSize = maxChunkSize;
        this.preserveStructure = preserveStructure;
    }
    
    public List<Document> apply(List<Document> documents) {
        List<Document> result = new ArrayList<>();
        
        for (Document doc : documents) {
            List<Document> chunks = splitDocument(doc);
            result.addAll(chunks);
        }
        
        return result;
    }
    
    public List<Document> splitDocument(Document document) {
        String text = document.getText();
        List<Document> chunks = new ArrayList<>();
        
        if (text.length() <= chunkSize) {
            return List.of(document);
        }
        
        List<String> textChunks = splitText(text);
        
        for (int i = 0; i < textChunks.size(); i++) {
            String chunk = textChunks.get(i);
            
            Map<String, Object> chunkMetadata = new HashMap<>(document.getMetadata());
            chunkMetadata.put("chunk_index", i);
            chunkMetadata.put("chunk_size", chunk.length());
            chunkMetadata.put("total_chunks", textChunks.size());
            
            chunks.add(new Document(chunk, chunkMetadata));
        }
        
        return chunks;
    }
    
    private List<String> splitText(String text) {
        List<String> chunks = new ArrayList<>();
        
        if (preserveStructure) {
            // Try to split on paragraphs first
            String[] paragraphs = text.split("\n\n+");
            StringBuilder currentChunk = new StringBuilder();
            
            for (String paragraph : paragraphs) {
                if (currentChunk.length() + paragraph.length() > chunkSize) {
                    if (currentChunk.length() >= minChunkSize) {
                        chunks.add(currentChunk.toString().trim());
                        currentChunk = new StringBuilder();
                        
                        // Add overlap from previous chunk
                        if (!chunks.isEmpty()) {
                            String lastChunk = chunks.get(chunks.size() - 1);
                            String overlap = getOverlapText(lastChunk, chunkOverlap);
                            currentChunk.append(overlap).append(" ");
                        }
                    }
                }
                
                if (paragraph.length() > maxChunkSize) {
                    // Split large paragraphs
                    List<String> subChunks = splitLargeParagraph(paragraph);
                    for (String subChunk : subChunks) {
                        if (currentChunk.length() + subChunk.length() > chunkSize) {
                            if (currentChunk.length() >= minChunkSize) {
                                chunks.add(currentChunk.toString().trim());
                                currentChunk = new StringBuilder();
                            }
                        }
                        currentChunk.append(subChunk).append(" ");
                    }
                } else {
                    currentChunk.append(paragraph).append("\n\n");
                }
            }
            
            if (currentChunk.length() >= minChunkSize) {
                chunks.add(currentChunk.toString().trim());
            }
        } else {
            // Simple character-based splitting
            int start = 0;
            while (start < text.length()) {
                int end = Math.min(start + chunkSize, text.length());
                
                // Try to break at word boundary
                if (end < text.length()) {
                    int lastSpace = text.lastIndexOf(' ', end);
                    if (lastSpace > start + chunkSize * 0.8) {
                        end = lastSpace;
                    }
                }
                
                chunks.add(text.substring(start, end).trim());
                start = end - chunkOverlap;
                if (start < 0) start = 0;
            }
        }
        
        return chunks;
    }
    
    private List<String> splitLargeParagraph(String paragraph) {
        List<String> sentences = Arrays.asList(paragraph.split("(?<=[.!?])\\s+"));
        List<String> chunks = new ArrayList<>();
        StringBuilder currentChunk = new StringBuilder();
        
        for (String sentence : sentences) {
            if (currentChunk.length() + sentence.length() > chunkSize) {
                if (currentChunk.length() > 0) {
                    chunks.add(currentChunk.toString().trim());
                    currentChunk = new StringBuilder();
                }
            }
            currentChunk.append(sentence).append(" ");
        }
        
        if (currentChunk.length() > 0) {
            chunks.add(currentChunk.toString().trim());
        }
        
        return chunks;
    }
    
    private String getOverlapText(String text, int overlapSize) {
        if (text.length() <= overlapSize) {
            return text;
        }
        
        String overlap = text.substring(text.length() - overlapSize);
        
        // Try to start at word boundary
        int firstSpace = overlap.indexOf(' ');
        if (firstSpace > 0) {
            overlap = overlap.substring(firstSpace + 1);
        }
        
        return overlap;
    }
}