package com.example.demo;

import java.util.Map;

/**
 * Document Analytics DTO
 */
public class DocumentAnalytics {
    private String documentId;
    private int totalChunks;
    private double averageConfidence;
    private int minChunkSize;
    private int maxChunkSize;
    private double averageChunkSize;
    private Map<String, Long> topicDistribution;
    private Map<String, Long> sectionDistribution;

    // Getters and Setters
    public String getDocumentId() { return documentId; }
    public void setDocumentId(String documentId) { this.documentId = documentId; }

    public int getTotalChunks() { return totalChunks; }
    public void setTotalChunks(int totalChunks) { this.totalChunks = totalChunks; }

    public double getAverageConfidence() { return averageConfidence; }
    public void setAverageConfidence(double averageConfidence) { this.averageConfidence = averageConfidence; }

    public int getMinChunkSize() { return minChunkSize; }
    public void setMinChunkSize(int minChunkSize) { this.minChunkSize = minChunkSize; }

    public int getMaxChunkSize() { return maxChunkSize; }
    public void setMaxChunkSize(int maxChunkSize) { this.maxChunkSize = maxChunkSize; }

    public double getAverageChunkSize() { return averageChunkSize; }
    public void setAverageChunkSize(double averageChunkSize) { this.averageChunkSize = averageChunkSize; }

    public Map<String, Long> getTopicDistribution() { return topicDistribution; }
    public void setTopicDistribution(Map<String, Long> topicDistribution) { this.topicDistribution = topicDistribution; }

    public Map<String, Long> getSectionDistribution() { return sectionDistribution; }
    public void setSectionDistribution(Map<String, Long> sectionDistribution) { this.sectionDistribution = sectionDistribution; }
}