package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import jakarta.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * AI Configuration for Spring AI and Ollama
 */
@Configuration
@EnableConfigurationProperties
public class AIConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(AIConfiguration.class);

    @Value("${ollama.base-url:http://localhost:11434}")
    private String ollamaBaseUrl;

    @Value("${ollama.embedding.model:nomic-embed-text}")
    private String embeddingModel;

    @Value("${ollama.chat.model:llama2}")
    private String chatModel;

//    @Bean
//    public OllamaService ollamaService() {
//        return new OllamaService(ollamaBaseUrl);
//    }

//    @Bean
//    public CustomPdfDocumentReader pdfDocumentReader() {
//        return new CustomPdfDocumentReader();
//    }

    @Bean
    public CustomTokenTextSplitter tokenTextSplitter() {
        return new CustomTokenTextSplitter(1000, 200, 100, 2000, true);
    }

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return mapper;
    }

    @Bean
    @ConditionalOnMissingBean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                    .allowedOrigins("*")
                    .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                    .allowedHeaders("*");
            }
        };
    }

    @PostConstruct
    public void validateConfiguration() {
        OllamaService service = new OllamaService(ollamaBaseUrl);
        
        if (!service.isModelAvailable(embeddingModel)) {
            logger.warn("Embedding model '{}' not available. Available models: {}", 
                embeddingModel, service.getAvailableModels());
        }
        
        if (!service.isModelAvailable(chatModel)) {
            logger.warn("Chat model '{}' not available. Available models: {}", 
                chatModel, service.getAvailableModels());
        }
    }
}