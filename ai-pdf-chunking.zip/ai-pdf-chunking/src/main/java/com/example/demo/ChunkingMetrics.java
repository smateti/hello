package com.example.demo;

import java.util.Map;

/**
 * Chunking Metrics Class
 */
public class ChunkingMetrics {
    private long processingTime;
    private int totalChunks;
    private double averageChunkSize;
    private double qualityScore;
    private int totalCharacters;
    private Map<String, Object> additionalMetrics;
    

    public long getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(long processingTime) {
        this.processingTime = processingTime;
    }

    public int getTotalChunks() {
        return totalChunks;
    }

    public void setTotalChunks(int totalChunks) {
        this.totalChunks = totalChunks;
    }

    public double getAverageChunkSize() {
        return averageChunkSize;
    }

    public void setAverageChunkSize(double averageChunkSize) {
        this.averageChunkSize = averageChunkSize;
    }

    public double getQualityScore() {
        return qualityScore;
    }

    public void setQualityScore(double qualityScore) {
        this.qualityScore = qualityScore;
    }

	public int getTotalCharacters() {
		return totalCharacters;
	}

	public void setTotalCharacters(int totalCharacters) {
		this.totalCharacters = totalCharacters;
	}

	public Map<String, Object> getAdditionalMetrics() {
		return additionalMetrics;
	}

	public void setAdditionalMetrics(Map<String, Object> additionalMetrics) {
		this.additionalMetrics = additionalMetrics;
	}
}