package com.example.demo;

import java.util.ArrayList;
import java.util.List;

/**
 * Semantic Section Class
 */
public class SemanticSection {
    private String content;
    private String title;

    public SemanticSection(String content, String title) {
        this.content = content;
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public String getTitle() {
        return title;
    }
}