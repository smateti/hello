package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository Interface for AI Document Chunks
 */
@Repository
public interface AIDocumentChunkRepository extends JpaRepository<AIDocumentChunk, Long> {
    List<AIDocumentChunk> findByDocumentIdOrderByChunkIndex(String documentId);
    List<AIDocumentChunk> findByChunkType(String chunkType);
    List<AIDocumentChunk> findByTopicCategory(String topicCategory);
    List<AIDocumentChunk> findByConfidenceScoreGreaterThan(Double threshold);
    void deleteByDocumentId(String documentId);
    
    @Query("SELECT c FROM AIDocumentChunk c WHERE c.keywords LIKE %:keyword%")
    List<AIDocumentChunk> findByKeywordsContaining(@Param("keyword") String keyword);
    
    @Query("SELECT c FROM AIDocumentChunk c WHERE c.semanticSummary LIKE %:term%")
    List<AIDocumentChunk> findBySummaryContaining(@Param("term") String term);
}