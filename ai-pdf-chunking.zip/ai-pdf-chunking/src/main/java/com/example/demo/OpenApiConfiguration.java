package com.example.demo;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * OpenAPI 3.0 Configuration for AI PDF Chunking Service
 */
@Configuration
@EnableWebMvc
public class OpenApiConfiguration {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("AI PDF Chunking Service")
                        .description("A powerful AI-driven PDF document chunking service using Ollama embeddings. " +
                                   "This service processes PDF documents, splits them into intelligent chunks using " +
                                   "various algorithms, and provides semantic search capabilities.")
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("AI PDF Chunking Team")
                                .email("support@aipdfchunking.com")
                                .url("https://github.com/example/ai-pdf-chunking"))
                        .license(new License()
                                .name("MIT License")
                                .url("https://opensource.org/licenses/MIT")));
    }
}