package com.example.demo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Section Info Class
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SectionInfo {
    private String title;
    private int position;
    private String type;

    public SectionInfo() {}

    public SectionInfo(String title, int position, String type) {
        this.title = title;
        this.position = position;
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

