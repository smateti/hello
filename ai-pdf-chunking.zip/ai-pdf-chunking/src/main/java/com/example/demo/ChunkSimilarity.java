package com.example.demo;
/**
 * Chunk Similarity Class
 */
public class ChunkSimilarity {
    private AIDocumentChunk chunk;
    private double similarity;

    public ChunkSimilarity(AIDocumentChunk chunk, double similarity) {
        this.chunk = chunk;
        this.similarity = similarity;
    }

    public AIDocumentChunk getChunk() {
        return chunk;
    }

    public double getSimilarity() {
        return similarity;
    }
}