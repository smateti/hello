package com.example.demo;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Test Controller for basic health checks with OpenAPI documentation
 */
@RestController
@RequestMapping("/api/test")
@Tag(name = "System Health", description = "System status and health monitoring endpoints")
public class TestController {

    private final OllamaService ollamaService;
    private final OllamaHealthIndicator healthIndicator;

    public TestController(OllamaService ollamaService, OllamaHealthIndicator healthIndicator) {
        this.ollamaService = ollamaService;
        this.healthIndicator = healthIndicator;
    }

    @GetMapping("/status")
    @Operation(
        summary = "Get application status", 
        description = "Returns basic application information and running status"
    )
    @ApiResponse(responseCode = "200", description = "Application status retrieved successfully")
    public Map<String, Object> getStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("application", "AI PDF Chunking Service");
        status.put("status", "running");
        status.put("timestamp", LocalDateTime.now());
        status.put("version", "1.0.0");
        status.put("ollama_healthy", healthIndicator.isHealthy());
        return status;
    }

    @GetMapping("/health")
    @Operation(
        summary = "Get health status", 
        description = "Comprehensive health check including Ollama connectivity"
    )
    @ApiResponse(responseCode = "200", description = "Health status retrieved successfully")
    public Map<String, Object> getHealth() {
        return healthIndicator.checkHealth();
    }

    @GetMapping("/ollama")
    @Operation(
        summary = "Check Ollama connection", 
        description = "Test connectivity to Ollama service and retrieve available models"
    )
    @ApiResponse(responseCode = "200", description = "Ollama status retrieved successfully")
    public Map<String, Object> checkOllama() {
        Map<String, Object> result = new HashMap<>();
        try {
            java.util.List<String> models = ollamaService.getAvailableModels();
            result.put("ollama_status", "connected");
            result.put("available_models", models);
            result.put("model_count", models.size());
        } catch (Exception e) {
            result.put("ollama_status", "disconnected");
            result.put("error", e.getMessage());
            result.put("suggestion", "Make sure Ollama is running on http://localhost:11434");
        }
        return result;
    }

    @GetMapping("/models")
    @Operation(
        summary = "Check required models", 
        description = "Verify that required AI models are available for processing"
    )
    @ApiResponse(responseCode = "200", description = "Model information retrieved successfully")
    public Map<String, Object> getModels() {
        Map<String, Object> result = new HashMap<>();
        try {
            java.util.List<String> models = ollamaService.getAvailableModels();
            result.put("models", models);
            
            // Check for required models
            boolean hasEmbeddingModel = models.stream().anyMatch(m -> m.contains("nomic-embed-text"));
            boolean hasChatModel = models.stream().anyMatch(m -> m.contains("llama"));
            
            result.put("has_embedding_model", hasEmbeddingModel);
            result.put("has_chat_model", hasChatModel);
            result.put("ready_for_processing", hasEmbeddingModel && hasChatModel);
            
            if (!hasEmbeddingModel) {
                result.put("missing_embedding", "Run: ollama pull nomic-embed-text");
            }
            if (!hasChatModel) {
                result.put("missing_chat", "Run: ollama pull llama2");
            }
            
        } catch (Exception e) {
            result.put("error", e.getMessage());
        }
        return result;
    }
}