package com.example.demo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Document Chunk Entity with AI metadata
 */
@Entity
@Table(name = "ai_document_chunks")
public class AIDocumentChunk {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "document_id", nullable = false)
    private String documentId;

    @Column(name = "chunk_index", nullable = false)
    private Integer chunkIndex;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @Column(name = "chunk_type")
    private String chunkType;

    @Column(name = "embedding", columnDefinition = "TEXT")
    private String embedding; // JSON serialized float array

    @Column(name = "semantic_summary", columnDefinition = "TEXT")
    private String semanticSummary;

    @Column(name = "keywords", columnDefinition = "TEXT")
    private String keywords;

    @Column(name = "topic_category")
    private String topicCategory;

    @Column(name = "confidence_score")
    private Double confidenceScore;

    @Column(name = "page_number")
    private Integer pageNumber;

    @Column(name = "section_title")
    private String sectionTitle;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(name = "strategy")
    private String strategy;
    
    @Column(name = "fileName")
    private String fileName;

    // Constructors
    public AIDocumentChunk() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public AIDocumentChunk(String documentId, Integer chunkIndex, String content, String chunkType) {
        this();
        this.documentId = documentId;
        this.chunkIndex = chunkIndex;
        this.content = content;
        this.chunkType = chunkType;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public Integer getChunkIndex() {
        return chunkIndex;
    }

    public void setChunkIndex(Integer chunkIndex) {
        this.chunkIndex = chunkIndex;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getChunkType() {
        return chunkType;
    }

    public void setChunkType(String chunkType) {
        this.chunkType = chunkType;
    }

    public String getEmbedding() {
        return embedding;
    }

    public void setEmbedding(String embedding) {
        this.embedding = embedding;
    }

    public String getSemanticSummary() {
        return semanticSummary;
    }

    public void setSemanticSummary(String semanticSummary) {
        this.semanticSummary = semanticSummary;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getTopicCategory() {
        return topicCategory;
    }

    public void setTopicCategory(String topicCategory) {
        this.topicCategory = topicCategory;
    }

    public Double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(Double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public String getSectionTitle() {
        return sectionTitle;
    }

    public void setSectionTitle(String sectionTitle) {
        this.sectionTitle = sectionTitle;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}