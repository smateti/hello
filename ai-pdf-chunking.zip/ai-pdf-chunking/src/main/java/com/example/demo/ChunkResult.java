package com.example.demo;

import java.util.HashMap;
import java.util.Map;

/**
 * Chunking Result Class
 */
public class ChunkResult {
	private String content;
	private Map<String, Object> metadata;
	private double confidenceScore;
	private String sectionTitle;
	private Integer pageNumber=0;

	private int startPosition;
	private int endPosition;
	private double confidence;

	public ChunkResult(String content, Map<String, Object> metadata) {
		this.content = content;
		this.metadata = metadata;
		this.confidenceScore = 1.0;
	}

	public ChunkResult(String content, Map<String, Object> metadata, int startPosition, int endPosition,
			double confidence) {
		this.content = content;
		this.metadata = metadata != null ? metadata : new HashMap<>();
		this.startPosition = startPosition;
		this.endPosition = endPosition;
		this.confidence = confidence;
	}

	// Getters and Setters
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Map<String, Object> getMetadata() {
		return metadata;
	}

	public void setMetadata(Map<String, Object> metadata) {
		this.metadata = metadata;
	}

	public double getConfidenceScore() {
		return confidenceScore;
	}

	public void setConfidenceScore(double confidenceScore) {
		this.confidenceScore = confidenceScore;
	}

	public String getSectionTitle() {
		return sectionTitle;
	}

	public void setSectionTitle(String sectionTitle) {
		this.sectionTitle = sectionTitle;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getStartPosition() {
		return startPosition;
	}

	public void setStartPosition(int startPosition) {
		this.startPosition = startPosition;
	}

	public int getEndPosition() {
		return endPosition;
	}

	public void setEndPosition(int endPosition) {
		this.endPosition = endPosition;
	}

	public double getConfidence() {
		return confidence;
	}

	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}
}
