package com.example.demo;
/**
 * Processing Result Class
 */
public class ProcessingResult {
    private String documentId;
    private String fileName;
    private String strategy;
    private int totalChunks;
    private long processingTime;
    private ChunkingMetrics metrics;

    // Getters and Setters
    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public int getTotalChunks() {
        return totalChunks;
    }

    public void setTotalChunks(int totalChunks) {
        this.totalChunks = totalChunks;
    }

    public long getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(long processingTime) {
        this.processingTime = processingTime;
    }

    public ChunkingMetrics getMetrics() {
        return metrics;
    }

    public void setMetrics(ChunkingMetrics metrics) {
        this.metrics = metrics;
    }
}

