package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * AI-Enhanced Semantic Chunking Strategy
 */
@Component
public class AISemanticChunkingStrategy implements AIChunkingStrategy {

    private static final Logger logger = LoggerFactory.getLogger(AISemanticChunkingStrategy.class);
    
    private final OllamaService ollamaService;
    private final ObjectMapper objectMapper;
    private ChunkingMetrics metrics;
    
    @Value("${ollama.embedding.model:nomic-embed-text}")
    private String embeddingModel;
    
    @Value("${ollama.chat.model:llama2}")
    private String chatModel;

    public AISemanticChunkingStrategy(OllamaService ollamaService, 
                                     ObjectMapper objectMapper) {
        this.ollamaService = ollamaService;
        this.objectMapper = objectMapper;
        this.metrics = new ChunkingMetrics();
    }

    @Override
    public List<ChunkResult> chunkDocument(Document document, ChunkingParameters parameters) {
        long startTime = System.currentTimeMillis();
        
        List<ChunkResult> results = new ArrayList<>();
        String content = document.getText();
        
        try {
            // Extract structure information using AI
            StructureInfo structureInfo = extractStructureInfo(content);
            
            // Split into semantic sections
            List<SemanticSection> sections = identifySemanticSections(content, parameters);
            
            for (SemanticSection section : sections) {
                List<ChunkResult> sectionChunks = chunkSection(section, parameters, structureInfo);
                results.addAll(sectionChunks);
            }
            
        } catch (Exception e) {
            logger.error("Error in AI semantic chunking, falling back to simple chunking", e);
            // Fallback to simple chunking
            results = fallbackChunking(content, parameters);
        }
        
        // Update metrics
        metrics.setProcessingTime(System.currentTimeMillis() - startTime);
        metrics.setTotalChunks(results.size());
        metrics.setAverageChunkSize(results.stream().mapToInt(r -> r.getContent().length()).average().orElse(0));
        
        return results;
    }

    private StructureInfo extractStructureInfo(String content) {
        String prompt = String.format("""
            Analyze this document and identify its structure. Return only a JSON response with:
            {
              "document_type": "research_paper|manual|report|article|other",
              "has_sections": true/false,
              "has_toc": true/false,
              "main_topics": ["topic1", "topic2", "topic3"]
            }
            
            Document excerpt (first 1500 chars):
            %s
            """, content.substring(0, Math.min(1500, content.length())));

        try {
            String response = ollamaService.generateChat(prompt, chatModel);
            
            // Try to extract JSON from response
            String jsonResponse = extractJsonFromResponse(response);
            return objectMapper.readValue(jsonResponse, StructureInfo.class);
            
        } catch (Exception e) {
            logger.warn("Failed to extract structure info with AI: {}", e.getMessage());
            // Return default structure info
            StructureInfo defaultInfo = new StructureInfo();
            defaultInfo.setDocumentType("unknown");
            defaultInfo.setHasToc(false);
            return defaultInfo;
        }
    }

    private List<SemanticSection> identifySemanticSections(String content, ChunkingParameters parameters) {
        List<SemanticSection> sections = new ArrayList<>();
        
        // Split by paragraphs first
        String[] paragraphs = content.split("\n\n+");
        
        List<String> currentSection = new ArrayList<>();
        List<List<Double>> embeddings = new ArrayList<>();
        
        for (String paragraph : paragraphs) {
            if (paragraph.trim().isEmpty()) continue;
            
            try {
                // Generate embedding for paragraph
                List<Double> embedding = ollamaService.generateEmbedding(paragraph, embeddingModel);
                
                // Calculate similarity with previous paragraphs
                if (!embeddings.isEmpty()) {
                    double avgSimilarity = calculateAverageSimilarity(embedding, embeddings);
                    
                    if (avgSimilarity < parameters.getSimilarityThreshold()) {
                        // Start new section
                        if (!currentSection.isEmpty()) {
                            sections.add(new SemanticSection(String.join("\n\n", currentSection), 
                                                           extractSectionTitle(currentSection.get(0))));
                            currentSection.clear();
                            embeddings.clear(); // Reset embeddings for new section
                        }
                    }
                }
                
                currentSection.add(paragraph);
                embeddings.add(embedding);
                
            } catch (Exception e) {
                logger.warn("Failed to generate embedding for paragraph, using text similarity", e);
                // Fallback to text-based similarity
                if (!currentSection.isEmpty()) {
                    double textSimilarity = calculateTextSimilarity(paragraph, currentSection.get(currentSection.size() - 1));
                    if (textSimilarity < parameters.getSimilarityThreshold()) {
                        sections.add(new SemanticSection(String.join("\n\n", currentSection), 
                                                       extractSectionTitle(currentSection.get(0))));
                        currentSection.clear();
                    }
                }
                currentSection.add(paragraph);
            }
        }
        
        if (!currentSection.isEmpty()) {
            sections.add(new SemanticSection(String.join("\n\n", currentSection), 
                                           extractSectionTitle(currentSection.get(0))));
        }
        
        return sections;
    }

    private List<ChunkResult> chunkSection(SemanticSection section, ChunkingParameters parameters, 
                                          StructureInfo structureInfo) {
        List<ChunkResult> chunks = new ArrayList<>();
        String content = section.getContent();
        
        // Use CustomTokenTextSplitter as base
        CustomTokenTextSplitter splitter = new CustomTokenTextSplitter(
            parameters.getChunkSize(),
            parameters.getOverlap(),
            parameters.getMinChunkSize(),
            parameters.getMaxChunkSize(),
            parameters.isPreserveStructure()
        );
        
        List<Document> splitDocs = splitter.apply(List.of(new Document(content)));
        
        for (int i = 0; i < splitDocs.size(); i++) {
            Document doc = splitDocs.get(i);
            ChunkResult result = new ChunkResult(doc.getText(), doc.getMetadata());
            
            // Enhance with AI analysis
            enhanceChunkWithAI(result, section.getTitle(), structureInfo);
            
            chunks.add(result);
        }
        
        return chunks;
    }

    private void enhanceChunkWithAI(ChunkResult chunk, String sectionTitle, StructureInfo structureInfo) {
        // Generate summary and keywords using AI
        String analysisPrompt = String.format("""
            Analyze this text chunk and provide:
            1. A brief summary (max 100 words)
            2. Key topics/keywords (comma-separated)
            3. Topic category (e.g., introduction, methodology, results, conclusion)
            4. Confidence score (0-1) for chunk quality
            
            Section: %s
            Text: %s
            """, sectionTitle, chunk.getContent());

        try {
            String response = ollamaService.generateChat(analysisPrompt, chatModel);
            parseAIAnalysis(response, chunk);
            chunk.setSectionTitle(sectionTitle);
        } catch (Exception e) {
            logger.warn("Failed to enhance chunk with AI analysis: {}", e.getMessage());
            // Fallback to basic analysis
            chunk.setConfidenceScore(0.8);
            chunk.setSectionTitle(sectionTitle);
        }
    }

    private void parseAIAnalysis(String response, ChunkResult chunk) {
        // Parse AI response and update chunk metadata
        String[] lines = response.split("\n");
        for (String line : lines) {
            if (line.toLowerCase().contains("summary:")) {
                chunk.getMetadata().put("summary", line.substring(line.indexOf(":") + 1).trim());
            } else if (line.toLowerCase().contains("keywords:")) {
                chunk.getMetadata().put("keywords", line.substring(line.indexOf(":") + 1).trim());
            } else if (line.toLowerCase().contains("category:")) {
                chunk.getMetadata().put("category", line.substring(line.indexOf(":") + 1).trim());
            } else if (line.toLowerCase().contains("confidence:")) {
                try {
                    String confStr = line.substring(line.indexOf(":") + 1).trim();
                    confStr = confStr.replaceAll("[^0-9.]", "");
                    double confidence = Double.parseDouble(confStr);
                    chunk.setConfidenceScore(confidence);
                } catch (NumberFormatException e) {
                    chunk.setConfidenceScore(0.8);
                }
            }
        }
    }

    private double calculateAverageSimilarity(List<Double> embedding, List<List<Double>> previousEmbeddings) {
        if (previousEmbeddings.isEmpty()) return 1.0;
        
        double totalSimilarity = 0.0;
        for (List<Double> prevEmbedding : previousEmbeddings) {
            totalSimilarity += calculateCosineSimilarity(embedding, prevEmbedding);
        }
        
        return totalSimilarity / previousEmbeddings.size();
    }

    private double calculateCosineSimilarity(List<Double> a, List<Double> b) {
        if (a.size() != b.size()) return 0.0;
        
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;
        
        for (int i = 0; i < a.size(); i++) {
            dotProduct += a.get(i) * b.get(i);
            normA += a.get(i) * a.get(i);
            normB += b.get(i) * b.get(i);
        }
        
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    private double calculateTextSimilarity(String text1, String text2) {
        // Simple word overlap similarity
        Set<String> words1 = new HashSet<>(Arrays.asList(text1.toLowerCase().split("\\s+")));
        Set<String> words2 = new HashSet<>(Arrays.asList(text2.toLowerCase().split("\\s+")));
        
        Set<String> intersection = new HashSet<>(words1);
        intersection.retainAll(words2);
        
        Set<String> union = new HashSet<>(words1);
        union.addAll(words2);
        
        return union.isEmpty() ? 0.0 : (double) intersection.size() / union.size();
    }

    private String extractSectionTitle(String firstParagraph) {
        String[] lines = firstParagraph.split("\n");
        for (String line : lines) {
            line = line.trim();
            if (line.length() > 0 && line.length() < 100 && 
                (line.matches("^[A-Z].*") || line.matches("^\\d+\\..*"))) {
                return line;
            }
        }
        return "Untitled Section";
    }

    private String extractJsonFromResponse(String response) {
        int start = response.indexOf('{');
        int end = response.lastIndexOf('}');
        if (start != -1 && end != -1 && end > start) {
            return response.substring(start, end + 1);
        }
        throw new IllegalArgumentException("No valid JSON found in response");
    }

    private List<ChunkResult> fallbackChunking(String content, ChunkingParameters parameters) {
        List<ChunkResult> results = new ArrayList<>();
        CustomTokenTextSplitter splitter = new CustomTokenTextSplitter(
            parameters.getChunkSize(),
            parameters.getOverlap(),
            parameters.getMinChunkSize(),
            parameters.getMaxChunkSize(),
            parameters.isPreserveStructure()
        );
        
        List<Document> docs = splitter.apply(List.of(new Document(content)));
        for (Document doc : docs) {
            ChunkResult result = new ChunkResult(doc.getText(), doc.getMetadata());
            result.setConfidenceScore(0.5); // Lower confidence for fallback
            results.add(result);
        }
        
        return results;
    }

    @Override
    public String getStrategyName() {
        return "AI_SEMANTIC";
    }

    @Override
    public ChunkingMetrics getMetrics() {
        return metrics;
    }
}