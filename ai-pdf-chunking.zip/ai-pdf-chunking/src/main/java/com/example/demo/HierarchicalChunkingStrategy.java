package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

@Component
public class HierarchicalChunkingStrategy implements AIChunkingStrategy {
    
    private ChunkingMetrics metrics;
    
    @Override
    public List<ChunkResult> chunkDocument(Document document, ChunkingParameters parameters) {
        long startTime = System.currentTimeMillis();
        
        String content = document.getText();
        List<ChunkResult> chunks = new ArrayList<>();
        
        // Detect document structure
        DocumentStructure structure = analyzeDocumentStructure(content);
        
        // Process by hierarchy levels
        chunks.addAll(processStructuredContent(content, structure, parameters, document));
        
        this.metrics = calculateHierarchicalMetrics(chunks, content, System.currentTimeMillis() - startTime);
        return chunks;
    }
    
    private DocumentStructure analyzeDocumentStructure(String content) {
        DocumentStructure structure = new DocumentStructure();
        
        // Detect headers (simple heuristic)
        String[] lines = content.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (isHeader(line)) {
                structure.addHeader(i, line, detectHeaderLevel(line));
            }
        }
        
        return structure;
    }
    
    private boolean isHeader(String line) {
        // Simple header detection heuristics
        return line.length() < 100 && 
               (line.matches("^[A-Z].*") && !line.endsWith(".") ||
                line.matches("^\\d+\\.\\s+.*") ||
                line.matches("^#+\\s+.*")); // Markdown headers
    }
    
    private int detectHeaderLevel(String line) {
        if (line.startsWith("###")) return 3;
        if (line.startsWith("##")) return 2;
        if (line.startsWith("#")) return 1;
        if (line.matches("^\\d+\\.\\s+.*")) return 2;
        return 1;
    }
    
    private List<ChunkResult> processStructuredContent(String content, DocumentStructure structure, 
                                                     ChunkingParameters parameters, Document document) {
        List<ChunkResult> chunks = new ArrayList<>();
        String[] lines = content.split("\n");
        
        List<StructureHeader> headers = structure.getHeaders();
        
        for (int i = 0; i < headers.size(); i++) {
            StructureHeader currentHeader = headers.get(i);
            StructureHeader nextHeader = (i + 1 < headers.size()) ? headers.get(i + 1) : null;
            
            int startLine = currentHeader.getLineNumber();
            int endLine = nextHeader != null ? nextHeader.getLineNumber() - 1 : lines.length - 1;
            
            // Extract section content
            StringBuilder sectionContent = new StringBuilder();
            int currentPosition = 0;
            
            for (int lineIdx = 0; lineIdx < startLine; lineIdx++) {
                currentPosition += lines[lineIdx].length() + 1; // +1 for newline
            }
            
            for (int lineIdx = startLine; lineIdx <= endLine; lineIdx++) {
                sectionContent.append(lines[lineIdx]).append("\n");
            }
            
            String section = sectionContent.toString().trim();
            
            // Split large sections further
            if (section.length() > parameters.getMaxChunkSize()) {
                chunks.addAll(splitLargeSection(section, currentHeader, parameters, document, currentPosition));
            } else if (section.length() >= parameters.getMinChunkSize()) {
                Map<String, Object> metadata = createHierarchicalMetadata(document, currentHeader, i);
                chunks.add(new ChunkResult(section, metadata, currentPosition, 
                         currentPosition + section.length(), 1.0));
            }
        }
        
        return chunks;
    }
    
    private List<ChunkResult> splitLargeSection(String section, StructureHeader header, 
                                              ChunkingParameters parameters, Document document, int basePosition) {
        List<ChunkResult> chunks = new ArrayList<>();
        
        // Split by paragraphs first
        String[] paragraphs = section.split("\n\n");
        StringBuilder currentChunk = new StringBuilder();
        int chunkIndex = 0;
        int currentPosition = basePosition;
        
        for (String paragraph : paragraphs) {
            if (currentChunk.length() + paragraph.length() > parameters.getMaxChunkSize()) {
                if (currentChunk.length() > 0) {
                    Map<String, Object> metadata = createHierarchicalMetadata(document, header, chunkIndex++);
                    metadata.put("subChunkIndex", chunkIndex);
                    
                    chunks.add(new ChunkResult(currentChunk.toString().trim(), metadata, 
                             currentPosition - currentChunk.length(), currentPosition, 1.0));
                    currentChunk = new StringBuilder();
                }
            }
            
            currentChunk.append(paragraph).append("\n\n");
            currentPosition += paragraph.length() + 2;
        }
        
        if (currentChunk.length() > 0) {
            Map<String, Object> metadata = createHierarchicalMetadata(document, header, chunkIndex);
            metadata.put("subChunkIndex", chunkIndex);
            
            chunks.add(new ChunkResult(currentChunk.toString().trim(), metadata, 
                     currentPosition - currentChunk.length(), currentPosition, 1.0));
        }
        
        return chunks;
    }
    
    private Map<String, Object> createHierarchicalMetadata(Document document, StructureHeader header, int chunkIndex) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("chunkIndex", chunkIndex);
        metadata.put("strategy", getStrategyName());
        metadata.put("headerText", header.getText());
        metadata.put("headerLevel", header.getLevel());
        metadata.put("sectionIndex", chunkIndex);
        metadata.put("originalDocumentId", document.getId());
        return metadata;
    }
    
    @Override
    public String getStrategyName() {
        return "HierarchicalChunking";
    }
    
    @Override
    public ChunkingMetrics getMetrics() {
        return metrics;
    }
    
    private ChunkingMetrics calculateHierarchicalMetrics(List<ChunkResult> chunks, String originalContent, long processingTime) {
        ChunkingMetrics metrics = new ChunkingMetrics();
        metrics.setTotalChunks(chunks.size());
        metrics.setProcessingTime(processingTime);
        metrics.setTotalCharacters(originalContent.length());
        
        if (!chunks.isEmpty()) {
            double avgSize = chunks.stream().mapToInt(c -> c.getContent().length()).average().orElse(0);
            metrics.setAverageChunkSize(avgSize);
            
            long sectionsCount = chunks.stream()
                .mapToLong(c -> (Integer) c.getMetadata().getOrDefault("sectionIndex", 0))
                .distinct()
                .count();
            metrics.getAdditionalMetrics().put("sectionsDetected", sectionsCount);
        }
        
        return metrics;
    }
    
    // Helper classes for document structure
    private static class DocumentStructure {
        private List<StructureHeader> headers = new ArrayList<>();
        
        public void addHeader(int lineNumber, String text, int level) {
            headers.add(new StructureHeader(lineNumber, text, level));
        }
        
        public List<StructureHeader> getHeaders() {
            return headers;
        }
    }
    
    private static class StructureHeader {
        private final int lineNumber;
        private final String text;
        private final int level;
        
        public StructureHeader(int lineNumber, String text, int level) {
            this.lineNumber = lineNumber;
            this.text = text;
            this.level = level;
        }
        
        public int getLineNumber() { return lineNumber; }
        public String getText() { return text; }
        public int getLevel() { return level; }
    }
}