package com.example.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.qdrant.client.QdrantClient;
import io.qdrant.client.grpc.Points.PointStruct;
import io.qdrant.client.grpc.Points.UpsertPoints;
import io.qdrant.client.grpc.Points.SearchPoints;
import io.qdrant.client.grpc.Points.ScoredPoint;
import io.qdrant.client.grpc.Points.Vector;
import io.qdrant.client.grpc.Points.Vectors;
import io.qdrant.client.grpc.Collections.Distance;
import io.qdrant.client.grpc.Collections.VectorParams;
import io.qdrant.client.grpc.Collections.CollectionInfo;
import io.qdrant.client.grpc.Collections.GetCollectionInfoRequest;
import io.qdrant.client.grpc.Collections.CreateCollection;
import io.qdrant.client.grpc.Points.WithPayloadSelector;
import io.qdrant.client.grpc.Points.PointId;
import io.qdrant.client.grpc.JsonWithInt.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * AI-Powered PDF Processing Service with Qdrant Vector Store
 */
@Service
@Transactional
public class AIPdfProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(AIPdfProcessingService.class);
    private static final String COLLECTION_NAME = "document_chunks";
    
    private final Map<String, AIChunkingStrategy> chunkingStrategies;
    private final OllamaService ollamaService;
    private final CustomPdfDocumentReader pdfReader;
    private final ObjectMapper objectMapper;
    private final QdrantClient qdrantClient;

    public AIPdfProcessingService(List<AIChunkingStrategy> strategies,
                                 OllamaService ollamaService,
                                 CustomPdfDocumentReader pdfReader,
                                 ObjectMapper objectMapper,
                                 QdrantClient qdrantClient) {
        this.chunkingStrategies = strategies.stream()
            .collect(Collectors.toMap(AIChunkingStrategy::getStrategyName, Function.identity()));
        this.ollamaService = ollamaService;
        this.pdfReader = pdfReader;
        this.objectMapper = objectMapper;
        this.qdrantClient = qdrantClient;
        initializeCollection();
    }

    private void initializeCollection() {
        try {
            // Check if collection already exists
         
            
            try {
                CollectionInfo collectionInfo = qdrantClient.getCollectionInfoAsync(COLLECTION_NAME).get();
                logger.info("Qdrant collection '{}' already exists with {} vectors", 
                    COLLECTION_NAME, collectionInfo.getStatus());
                return;
            } catch (Exception e) {
                // Collection doesn't exist, create it
                logger.info("Collection '{}' doesn't exist, creating it...", COLLECTION_NAME);
            }
            
            
            // Create collection
            VectorParams vectorParams = VectorParams.newBuilder()
                .setSize(768) // Adjust based on your embedding model dimension
                .setDistance(Distance.Cosine)
                .build();
            
            io.qdrant.client.grpc.Collections.VectorsConfig vectorsConfig = 
                io.qdrant.client.grpc.Collections.VectorsConfig.newBuilder()
                .setParams(vectorParams)
                .build();
            
            CreateCollection createCollection = CreateCollection.newBuilder()
                .setCollectionName(COLLECTION_NAME)
                .setVectorsConfig(vectorsConfig)
                .build();
            
            qdrantClient.createCollectionAsync(createCollection).get();
            logger.info("Qdrant collection '{}' created successfully", COLLECTION_NAME);
            
        } catch (Exception e) {
            logger.error("Failed to initialize Qdrant collection '{}': {}", COLLECTION_NAME, e.getMessage());
            throw new RuntimeException("Failed to initialize Qdrant collection", e);
        }
    }

    public ProcessingResult processDocument(MultipartFile file, String strategyName, 
                                          ChunkingParameters parameters) throws IOException {
        long startTime = System.currentTimeMillis();
        
        // Extract text from PDF
        String text = pdfReader.extractTextOnly(file);
        Document document = new Document(text);
        
        String documentId = UUID.randomUUID().toString();
        
        // Get chunking strategy
        AIChunkingStrategy strategy = chunkingStrategies.get(strategyName);
        if (strategy == null) {
            throw new IllegalArgumentException("Unknown chunking strategy: " + strategyName);
        }
        
        // Process document
        List<ChunkResult> chunkResults = strategy.chunkDocument(document, parameters);
        
        // Prepare points for Qdrant
        List<PointStruct> points = new ArrayList<>();
        for (int i = 0; i < chunkResults.size(); i++) {
            ChunkResult result = chunkResults.get(i);
            
            // Generate embedding
            try {
                List<Double> embedding = ollamaService.generateEmbedding(result.getContent(), parameters.getEmbeddingModel());
                
                // Create point for Qdrant
                PointStruct point = createQdrantPoint(
                    documentId, i, result, embedding, strategyName, file.getOriginalFilename()
                );
                points.add(point);
                
            } catch (Exception e) {
                logger.warn("Failed to generate embedding for chunk {}: {}", i, e.getMessage());
            }
        }
        
        // Upsert points to Qdrant
        try {
            UpsertPoints upsertPoints = UpsertPoints.newBuilder()
                .setCollectionName(COLLECTION_NAME)
                .addAllPoints(points)
                .build();
            
            qdrantClient.upsertAsync(upsertPoints).get();
            logger.info("Successfully stored {} chunks in Qdrant", points.size());
        } catch (Exception e) {
            logger.error("Failed to store chunks in Qdrant: {}", e.getMessage());
            throw new RuntimeException("Failed to store document chunks", e);
        }
        
        // Create processing result
        ProcessingResult result = new ProcessingResult();
        result.setDocumentId(documentId);
        result.setFileName(file.getOriginalFilename());
        result.setStrategy(strategyName);
        result.setTotalChunks(points.size());
        result.setProcessingTime(System.currentTimeMillis() - startTime);
        result.setMetrics(strategy.getMetrics());
        
        return result;
    }

    public List<AIDocumentChunk> searchSimilarChunks(String query, int limit, double threshold) {
        try {
            // Generate embedding for query
            List<Double> queryEmbedding = ollamaService.generateEmbedding(query, "nomic-embed-text");
            
            // Convert Double list to List<Float> for Qdrant
            List<Float> queryVector = queryEmbedding.stream()
                .map(Double::floatValue)
                .collect(Collectors.toList());
            
            // Search in Qdrant
            SearchPoints searchPoints = SearchPoints.newBuilder()
                .setCollectionName(COLLECTION_NAME)
                .addAllVector(queryVector)
                .setLimit(limit)
                .setScoreThreshold((float) threshold)
                .setWithPayload(WithPayloadSelector.newBuilder()
                    .setEnable(true)
                    .build())
                .build();
            
            List<ScoredPoint> searchResult = qdrantClient.searchAsync(searchPoints).get();
            
            // Convert results to AIDocumentChunk objects
            return searchResult.stream()
                .map(this::convertToAIDocumentChunk)
                .collect(Collectors.toList());
                
        } catch (Exception e) {
            logger.error("Failed to search similar chunks: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    public String generateChunkSummary(String documentId) {
        try {
            // Search for all chunks of the document
            List<AIDocumentChunk> chunks = getChunksByDocumentId(documentId);
            
            if (chunks.isEmpty()) {
                return "No chunks found for document";
            }
            
            // Combine chunk summaries
            String combinedSummaries = chunks.stream()
                .filter(chunk -> chunk.getSemanticSummary() != null)
                .map(AIDocumentChunk::getSemanticSummary)
                .collect(Collectors.joining("\n\n"));
            
            // Generate overall summary using AI
            String prompt = String.format("""
                Based on these individual chunk summaries, provide a comprehensive 
                document summary (max 300 words):
                
                %s
                """, combinedSummaries);
            
            return ollamaService.generateChat(prompt, "llama2");
        } catch (Exception e) {
            logger.error("Failed to generate document summary: {}", e.getMessage());
            return "Failed to generate summary";
        }
    }

    private List<AIDocumentChunk> getChunksByDocumentId(String documentId) {
        try {
            // Use scroll or search with filter to get all chunks for a document
            // This is a simplified approach - in production, you might want to use filtering
            List<Float> dummyVector = Collections.nCopies(768, 0.0f);
            
            SearchPoints searchPoints = SearchPoints.newBuilder()
                .setCollectionName(COLLECTION_NAME)
                .addAllVector(dummyVector)
                .setLimit(1000) // Adjust based on expected document size
                .setWithPayload(WithPayloadSelector.newBuilder()
                    .setEnable(true)
                    .build())
                .build();
            
            List<ScoredPoint> allPoints = qdrantClient.searchAsync(searchPoints).get();
            
            return allPoints.stream()
                .filter(point -> {
                    Value docIdValue = point.getPayloadMap().get("documentId");
                    return docIdValue != null && documentId.equals(docIdValue.getStringValue());
                })
                .map(this::convertToAIDocumentChunk)
                .sorted(Comparator.comparingInt(AIDocumentChunk::getChunkIndex))
                .collect(Collectors.toList());
                
        } catch (Exception e) {
            logger.error("Failed to get chunks by document ID: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    private PointStruct createQdrantPoint(String documentId, int chunkIndex, ChunkResult result, 
                                         List<Double> embedding, String strategyName, String fileName) {
        
        // Convert embedding to List<Float> for Qdrant
        List<Float> vectorList = embedding.stream()
            .map(Double::floatValue)
            .collect(Collectors.toList());
        
        // Create vector
        Vector vector = Vector.newBuilder()
            .addAllData(vectorList)
            .build();
        
        // Create payload
        Map<String, Value> payload = new HashMap<>();
        payload.put("documentId", Value.newBuilder().setStringValue(documentId).build());
        payload.put("chunkIndex", Value.newBuilder().setIntegerValue(chunkIndex).build());
        payload.put("content", Value.newBuilder().setStringValue(result.getContent()).build());
        payload.put("strategy", Value.newBuilder().setStringValue(strategyName).build());
        payload.put("fileName", Value.newBuilder().setStringValue(fileName).build());
        payload.put("confidenceScore", Value.newBuilder().setDoubleValue(result.getConfidenceScore()).build());
        payload.put("sectionTitle", Value.newBuilder().setStringValue(result.getSectionTitle() != null ? result.getSectionTitle() : "").build());
        payload.put("pageNumber", Value.newBuilder().setIntegerValue(result.getPageNumber()).build());
        
        // Add metadata
        Object summary = result.getMetadata().get("summary");
        if (summary != null) {
            payload.put("semanticSummary", Value.newBuilder().setStringValue(summary.toString()).build());
        }
        
        Object keywords = result.getMetadata().get("keywords");
        if (keywords != null) {
            payload.put("keywords", Value.newBuilder().setStringValue(keywords.toString()).build());
        }
        
        Object category = result.getMetadata().get("category");
        if (category != null) {
            payload.put("topicCategory", Value.newBuilder().setStringValue(category.toString()).build());
        }
        
        // Create point
        return PointStruct.newBuilder()
            .setId(PointId.newBuilder().setUuid(UUID.randomUUID().toString()).build())
            .setVectors(Vectors.newBuilder().setVector(vector).build())
            .putAllPayload(payload)
            .build();
    }

    private AIDocumentChunk convertToAIDocumentChunk(ScoredPoint point) {
        Map<String, Value> payload = point.getPayloadMap();
        
        AIDocumentChunk chunk = new AIDocumentChunk();
        
        chunk.setDocumentId(getStringValue(payload, "documentId"));
        chunk.setChunkIndex(getIntValue(payload, "chunkIndex"));
        chunk.setContent(getStringValue(payload, "content"));
        chunk.setStrategy(getStringValue(payload, "strategy"));
        chunk.setFileName(getStringValue(payload, "fileName"));
        chunk.setConfidenceScore(getDoubleValue(payload, "confidenceScore"));
        chunk.setSectionTitle(getStringValue(payload, "sectionTitle"));
        chunk.setPageNumber(getIntValue(payload, "pageNumber"));
        chunk.setSemanticSummary(getStringValue(payload, "semanticSummary"));
        chunk.setKeywords(getStringValue(payload, "keywords"));
        chunk.setTopicCategory(getStringValue(payload, "topicCategory"));
        
        return chunk;
    }
    
    private String getStringValue(Map<String, Value> payload, String key) {
        Value value = payload.get(key);
        return value != null ? value.getStringValue() : null;
    }
    
    private int getIntValue(Map<String, Value> payload, String key) {
        Value value = payload.get(key);
        return value != null ? (int) value.getIntegerValue() : 0;
    }
    
    private double getDoubleValue(Map<String, Value> payload, String key) {
        Value value = payload.get(key);
        return value != null ? value.getDoubleValue() : 0.0;
    }
}