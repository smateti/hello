package com.example.demo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Enhanced REST Controller for AI PDF Processing
 */
@RestController
@RequestMapping("/api/ai-documents")
@Validated
public class AIPdfController {

    private final AIPdfProcessingService processingService;
    private final AIDocumentChunkRepository chunkRepository;

    public AIPdfController(AIPdfProcessingService processingService,
                          AIDocumentChunkRepository chunkRepository) {
        this.processingService = processingService;
        this.chunkRepository = chunkRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<ProcessingResult> uploadDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "strategy", defaultValue = "AI_SEMANTIC") String strategy,
            @RequestParam(value = "chunkSize", defaultValue = "1000") int chunkSize,
            @RequestParam(value = "overlap", defaultValue = "200") int overlap,
            @RequestParam(value = "minChunkSize", defaultValue = "100") int minChunkSize,
            @RequestParam(value = "maxChunkSize", defaultValue = "2000") int maxChunkSize,
            @RequestParam(value = "similarityThreshold", defaultValue = "0.7") double similarityThreshold,
            @RequestParam(value = "preserveStructure", defaultValue = "true") boolean preserveStructure) {
        
        try {
            // Validate file
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
            
            if (!"application/pdf".equals(file.getContentType())) {
                return ResponseEntity.badRequest().build();
            }
            
            // Create chunking parameters
            ChunkingParameters parameters = new ChunkingParameters();
            parameters.setChunkSize(chunkSize);
            parameters.setOverlap(overlap);
            parameters.setMinChunkSize(minChunkSize);
            parameters.setMaxChunkSize(maxChunkSize);
            parameters.setSimilarityThreshold(similarityThreshold);
            parameters.setPreserveStructure(preserveStructure);
            
            // Process document
            ProcessingResult result = processingService.processDocument(file, strategy, parameters);
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<ChunkSearchResult>> searchChunks(
            @RequestParam("query") String query,
            @RequestParam(value = "limit", defaultValue = "10") int limit,
            @RequestParam(value = "threshold", defaultValue = "0.5") double threshold) {
        
        try {
            List<AIDocumentChunk> chunks = processingService.searchSimilarChunks(query, limit, threshold);
            
            List<ChunkSearchResult> results = chunks.stream()
                .map(chunk -> new ChunkSearchResult(
                    chunk.getId(),
                    chunk.getDocumentId(),
                    chunk.getChunkIndex(),
                    chunk.getContent(),
                    chunk.getSemanticSummary(),
                    chunk.getKeywords(),
                    chunk.getTopicCategory(),
                    chunk.getConfidenceScore(),
                    chunk.getSectionTitle()
                ))
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(results);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Collections.emptyList());
        }
    }

    @GetMapping("/{documentId}/summary")
    public ResponseEntity<DocumentSummary> getDocumentSummary(@PathVariable String documentId) {
        try {
            String summary = processingService.generateChunkSummary(documentId);
            List<AIDocumentChunk> chunks = chunkRepository.findByDocumentIdOrderByChunkIndex(documentId);
            
            // Generate document statistics
            DocumentSummary docSummary = new DocumentSummary();
            docSummary.setDocumentId(documentId);
            docSummary.setSummary(summary);
            docSummary.setTotalChunks(chunks.size());
            docSummary.setAverageConfidence(chunks.stream()
                .mapToDouble(c -> c.getConfidenceScore() != null ? c.getConfidenceScore() : 0.0)
                .average().orElse(0.0));
            
            // Extract topic categories
            Map<String, Long> topicDistribution = chunks.stream()
                .filter(c -> c.getTopicCategory() != null)
                .collect(Collectors.groupingBy(
                    AIDocumentChunk::getTopicCategory,
                    Collectors.counting()));
            docSummary.setTopicDistribution(topicDistribution);
            
            // Extract keywords
            Set<String> allKeywords = chunks.stream()
                .filter(c -> c.getKeywords() != null)
                .flatMap(c -> Arrays.stream(c.getKeywords().split(",")))
                .map(String::trim)
                .collect(Collectors.toSet());
            docSummary.setKeywords(new ArrayList<>(allKeywords));
            
            return ResponseEntity.ok(docSummary);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{documentId}/chunks")
    public ResponseEntity<List<AIDocumentChunk>> getDocumentChunks(
            @PathVariable String documentId,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "20") int size) {
        
        try {
            List<AIDocumentChunk> chunks = chunkRepository.findByDocumentIdOrderByChunkIndex(documentId);
            
            // Manual pagination
            int start = page * size;
            int end = Math.min(start + size, chunks.size());
            
            if (start >= chunks.size()) {
                return ResponseEntity.ok(Collections.emptyList());
            }
            
            return ResponseEntity.ok(chunks.subList(start, end));
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/analytics/{documentId}")
    public ResponseEntity<DocumentAnalytics> getDocumentAnalytics(@PathVariable String documentId) {
        try {
            List<AIDocumentChunk> chunks = chunkRepository.findByDocumentIdOrderByChunkIndex(documentId);
            
            if (chunks.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            DocumentAnalytics analytics = new DocumentAnalytics();
            analytics.setDocumentId(documentId);
            analytics.setTotalChunks(chunks.size());
            
            // Confidence score distribution
            double avgConfidence = chunks.stream()
                .mapToDouble(c -> c.getConfidenceScore() != null ? c.getConfidenceScore() : 0.0)
                .average().orElse(0.0);
            analytics.setAverageConfidence(avgConfidence);
            
            // Chunk size distribution
            IntSummaryStatistics sizeStats = chunks.stream()
                .mapToInt(c -> c.getContent() != null ? c.getContent().length() : 0)
                .summaryStatistics();
            analytics.setMinChunkSize(sizeStats.getMin());
            analytics.setMaxChunkSize(sizeStats.getMax());
            analytics.setAverageChunkSize(sizeStats.getAverage());
            
            // Topic category distribution
            Map<String, Long> topicDistribution = chunks.stream()
                .filter(c -> c.getTopicCategory() != null)
                .collect(Collectors.groupingBy(
                    AIDocumentChunk::getTopicCategory,
                    Collectors.counting()));
            analytics.setTopicDistribution(topicDistribution);
            
            // Section distribution
            Map<String, Long> sectionDistribution = chunks.stream()
                .filter(c -> c.getSectionTitle() != null)
                .collect(Collectors.groupingBy(
                    AIDocumentChunk::getSectionTitle,
                    Collectors.counting()));
            analytics.setSectionDistribution(sectionDistribution);
            
            return ResponseEntity.ok(analytics);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{documentId}")
    public ResponseEntity<Map<String, String>> deleteDocument(@PathVariable String documentId) {
        try {
            chunkRepository.deleteByDocumentId(documentId);
            return ResponseEntity.ok(Map.of("message", "Document deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to delete document"));
        }
    }

    @GetMapping("/search/by-keywords")
    public ResponseEntity<List<AIDocumentChunk>> searchByKeywords(@RequestParam String keyword) {
        try {
            List<AIDocumentChunk> chunks = chunkRepository.findByKeywordsContaining(keyword);
            return ResponseEntity.ok(chunks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Collections.emptyList());
        }
    }

    @GetMapping("/search/by-category")
    public ResponseEntity<List<AIDocumentChunk>> searchByCategory(@RequestParam String category) {
        try {
            List<AIDocumentChunk> chunks = chunkRepository.findByTopicCategory(category);
            return ResponseEntity.ok(chunks);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Collections.emptyList());
        }
    }
}