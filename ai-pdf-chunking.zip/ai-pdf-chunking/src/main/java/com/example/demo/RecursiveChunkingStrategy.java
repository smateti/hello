package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;

@Component
public class RecursiveChunkingStrategy implements AIChunkingStrategy {
    
    private ChunkingMetrics metrics;
    
    @Override
    public List<ChunkResult> chunkDocument(Document document, ChunkingParameters parameters) {
        long startTime = System.currentTimeMillis();
        
        List<ChunkResult> chunks = splitRecursively(
            document.getText(), 
            parameters.getSeparators(), 
            parameters.getMaxChunkSize(),
            parameters.getOverlap(),
            document
        );
        
        this.metrics = calculateMetrics(chunks, document.getText(), System.currentTimeMillis() - startTime);
        return chunks;
    }
    
    private List<ChunkResult> splitRecursively(String text, String[] separators, 
                                             int maxSize, int overlap, Document document) {
        List<ChunkResult> chunks = new ArrayList<>();
        
        if (text.length() <= maxSize) {
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("strategy", getStrategyName());
            metadata.put("originalDocumentId", document.getId());
            chunks.add(new ChunkResult(text, metadata, 0, text.length(), 1.0));
            return chunks;
        }
        
        String separator = findBestSeparator(text, separators, maxSize);
        
        if (separator != null) {
            String[] parts = text.split(Pattern.quote(separator), -1);
            StringBuilder currentChunk = new StringBuilder();
            int currentPosition = 0;
            int chunkIndex = 0;
            
            for (int i = 0; i < parts.length; i++) {
                String part = parts[i];
                
                if (currentChunk.length() + part.length() + separator.length() <= maxSize) {
                    if (currentChunk.length() > 0) {
                        currentChunk.append(separator);
                        currentPosition += separator.length();
                    }
                    currentChunk.append(part);
                    currentPosition += part.length();
                } else {
                    if (currentChunk.length() > 0) {
                        Map<String, Object> metadata = createChunkMetadata(document, chunkIndex++);
                        chunks.add(new ChunkResult(currentChunk.toString(), metadata, 
                                 currentPosition - currentChunk.length(), currentPosition, 1.0));
                        
                        // Handle overlap
                        currentChunk = new StringBuilder();
                        if (overlap > 0 && chunks.size() > 0) {
                            String lastChunk = chunks.get(chunks.size() - 1).getContent();
                            int overlapStart = Math.max(0, lastChunk.length() - overlap);
                            currentChunk.append(lastChunk.substring(overlapStart));
                        }
                    }
                    
                    currentChunk.append(part);
                    currentPosition += part.length();
                }
            }
            
            if (currentChunk.length() > 0) {
                Map<String, Object> metadata = createChunkMetadata(document, chunkIndex);
                chunks.add(new ChunkResult(currentChunk.toString(), metadata, 
                         currentPosition - currentChunk.length(), currentPosition, 1.0));
            }
        } else {
            // Fallback to character-based splitting
            chunks = fallbackSplit(text, maxSize, overlap, document);
        }
        
        return chunks;
    }
    
    private String findBestSeparator(String text, String[] separators, int maxSize) {
        for (String separator : separators) {
            if (text.contains(separator)) {
                int index = text.indexOf(separator);
                if (index > 0 && index < maxSize) {
                    return separator;
                }
            }
        }
        return null;
    }
    
    private List<ChunkResult> fallbackSplit(String text, int maxSize, int overlap, Document document) {
        List<ChunkResult> chunks = new ArrayList<>();
        int start = 0;
        int chunkIndex = 0;
        
        while (start < text.length()) {
            int end = Math.min(start + maxSize, text.length());
            String chunkContent = text.substring(start, end);
            
            Map<String, Object> metadata = createChunkMetadata(document, chunkIndex++);
            chunks.add(new ChunkResult(chunkContent, metadata, start, end, 0.8)); // Lower confidence
            
            start = end - overlap;
        }
        
        return chunks;
    }
    
    private Map<String, Object> createChunkMetadata(Document document, int chunkIndex) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("chunkIndex", chunkIndex);
        metadata.put("strategy", getStrategyName());
        metadata.put("originalDocumentId", document.getId());
        return metadata;
    }
    
    @Override
    public String getStrategyName() {
        return "RecursiveChunking";
    }
    
    @Override
    public ChunkingMetrics getMetrics() {
        return metrics;
    }
    
    private ChunkingMetrics calculateMetrics(List<ChunkResult> chunks, String originalContent, long processingTime) {
        ChunkingMetrics metrics = new ChunkingMetrics();
        metrics.setTotalChunks(chunks.size());
        metrics.setProcessingTime(processingTime);
        metrics.setTotalCharacters(originalContent.length());
        
        if (!chunks.isEmpty()) {
            double avgSize = chunks.stream().mapToInt(c -> c.getContent().length()).average().orElse(0);
            metrics.setAverageChunkSize(avgSize);
        }
        
        return metrics;
    }
}