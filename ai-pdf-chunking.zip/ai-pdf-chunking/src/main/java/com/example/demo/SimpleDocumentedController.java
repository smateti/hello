package com.example.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Simple REST Controller for AI PDF Processing with basic OpenAPI support
 * This version uses minimal annotations to ensure compatibility
 */
@RestController
@RequestMapping("/api/documents")
@Validated
public class SimpleDocumentedController {

    private final AIPdfProcessingService processingService;
    private final AIDocumentChunkRepository chunkRepository;

    public SimpleDocumentedController(AIPdfProcessingService processingService,
                                     AIDocumentChunkRepository chunkRepository) {
        this.processingService = processingService;
        this.chunkRepository = chunkRepository;
    }

    /**
     * Upload and process PDF document
     * 
     * @param file PDF file to process
     * @param strategy Chunking strategy (AI_SEMANTIC, FIXED_SIZE, PARAGRAPH)
     * @param chunkSize Target chunk size in characters
     * @param overlap Overlap between chunks
     * @param minChunkSize Minimum chunk size
     * @param maxChunkSize Maximum chunk size
     * @param similarityThreshold Similarity threshold (0.0-1.0)
     * @param preserveStructure Whether to preserve document structure
     * @return Processing result with document ID and statistics
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ProcessingResult> uploadDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "strategy", defaultValue = "AI_SEMANTIC") String strategy,
            @RequestParam(value = "chunkSize", defaultValue = "1000") int chunkSize,
            @RequestParam(value = "overlap", defaultValue = "200") int overlap,
            @RequestParam(value = "minChunkSize", defaultValue = "100") int minChunkSize,
            @RequestParam(value = "maxChunkSize", defaultValue = "2000") int maxChunkSize,
            @RequestParam(value = "similarityThreshold", defaultValue = "0.7") double similarityThreshold,
            @RequestParam(value = "preserveStructure", defaultValue = "true") boolean preserveStructure) {
        
        try {
            if (file.isEmpty() || !"application/pdf".equals(file.getContentType())) {
                return ResponseEntity.badRequest().build();
            }
            
            ChunkingParameters parameters = new ChunkingParameters();
            parameters.setChunkSize(chunkSize);
            parameters.setOverlap(overlap);
            parameters.setMinChunkSize(minChunkSize);
            parameters.setMaxChunkSize(maxChunkSize);
            parameters.setSimilarityThreshold(similarityThreshold);
            parameters.setPreserveStructure(preserveStructure);
            
            ProcessingResult result = processingService.processDocument(file, strategy, parameters);
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Search similar chunks using semantic search
     * 
     * @param query Search query text
     * @param limit Maximum number of results
     * @param threshold Similarity threshold
     * @return List of matching chunks with similarity scores
     */
    @GetMapping("/search")
    public ResponseEntity<List<ChunkSearchResult>> searchChunks(
            @RequestParam("query") String query,
            @RequestParam(value = "limit", defaultValue = "10") int limit,
            @RequestParam(value = "threshold", defaultValue = "0.5") double threshold) {
        
        try {
            List<AIDocumentChunk> chunks = processingService.searchSimilarChunks(query, limit, threshold);
            
            List<ChunkSearchResult> results = chunks.stream()
                .map(chunk -> new ChunkSearchResult(
                    chunk.getId(),
                    chunk.getDocumentId(),
                    chunk.getChunkIndex(),
                    chunk.getContent(),
                    chunk.getSemanticSummary(),
                    chunk.getKeywords(),
                    chunk.getTopicCategory(),
                    chunk.getConfidenceScore(),
                    chunk.getSectionTitle()
                ))
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(results);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Collections.emptyList());
        }
    }

    /**
     * Get AI-generated document summary
     * 
     * @param documentId Document ID
     * @return Document summary with statistics and insights
     */
    @GetMapping("/{documentId}/summary")
    public ResponseEntity<DocumentSummary> getDocumentSummary(@PathVariable String documentId) {
        try {
            String summary = processingService.generateChunkSummary(documentId);
            List<AIDocumentChunk> chunks = chunkRepository.findByDocumentIdOrderByChunkIndex(documentId);
            
            DocumentSummary docSummary = new DocumentSummary();
            docSummary.setDocumentId(documentId);
            docSummary.setSummary(summary);
            docSummary.setTotalChunks(chunks.size());
            docSummary.setAverageConfidence(chunks.stream()
                .mapToDouble(c -> c.getConfidenceScore() != null ? c.getConfidenceScore() : 0.0)
                .average().orElse(0.0));
            
            Map<String, Long> topicDistribution = chunks.stream()
                .filter(c -> c.getTopicCategory() != null)
                .collect(Collectors.groupingBy(
                    AIDocumentChunk::getTopicCategory,
                    Collectors.counting()));
            docSummary.setTopicDistribution(topicDistribution);
            
            Set<String> allKeywords = chunks.stream()
                .filter(c -> c.getKeywords() != null)
                .flatMap(c -> Arrays.stream(c.getKeywords().split(",")))
                .map(String::trim)
                .collect(Collectors.toSet());
            docSummary.setKeywords(new ArrayList<>(allKeywords));
            
            return ResponseEntity.ok(docSummary);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get document chunks with pagination
     * 
     * @param documentId Document ID
     * @param page Page number (0-based)
     * @param size Page size
     * @return Paginated list of document chunks
     */
    @GetMapping("/{documentId}/chunks")
    public ResponseEntity<List<AIDocumentChunk>> getDocumentChunks(
            @PathVariable String documentId,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "20") int size) {
        
        try {
            List<AIDocumentChunk> chunks = chunkRepository.findByDocumentIdOrderByChunkIndex(documentId);
            
            int start = page * size;
            int end = Math.min(start + size, chunks.size());
            
            if (start >= chunks.size()) {
                return ResponseEntity.ok(Collections.emptyList());
            }
            
            return ResponseEntity.ok(chunks.subList(start, end));
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Delete document and all its chunks
     * 
     * @param documentId Document ID
     * @return Success/error message
     */
    @DeleteMapping("/{documentId}")
    public ResponseEntity<Map<String, String>> deleteDocument(@PathVariable String documentId) {
        try {
            chunkRepository.deleteByDocumentId(documentId);
            return ResponseEntity.ok(Map.of("message", "Document deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to delete document"));
        }
    }
}