package com.example.demo;

import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;

/**
 * Health Check for Ollama Service (without Spring Boot Actuator dependency)
 */
@Component
public class OllamaHealthIndicator {

    private final OllamaService ollamaService;
    
    public OllamaHealthIndicator(OllamaService ollamaService) {
        this.ollamaService = ollamaService;
    }

    public Map<String, Object> checkHealth() {
        Map<String, Object> health = new HashMap<>();
        
        try {
            // Check if Ollama is running by getting available models
            java.util.List<String> models = ollamaService.getAvailableModels();
            
            if (!models.isEmpty()) {
                health.put("status", "UP");
                health.put("ollama", "Available");
                health.put("models", models);
                health.put("model_count", models.size());
            } else {
                health.put("status", "DOWN");
                health.put("ollama", "No models available");
                health.put("error", "Ollama service may not be running or no models installed");
            }
        } catch (Exception e) {
            health.put("status", "DOWN");
            health.put("ollama", "Unavailable");
            health.put("error", e.getMessage());
            health.put("suggestion", "Check if Ollama is running on http://localhost:11434");
        }
        
        return health;
    }
    
    public boolean isHealthy() {
        try {
            java.util.List<String> models = ollamaService.getAvailableModels();
            return !models.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
}