// Strategy parameter handling
document.getElementById('strategy').addEventListener('change', function() {
    const strategy = this.value;
    const paramGroups = document.querySelectorAll('.strategy-params');
    
    paramGroups.forEach(group => {
        const strategies = group.getAttribute('data-strategy').split(',');
        if (strategies.includes(strategy)) {
            group.style.display = 'block';
        } else {
            group.style.display = 'none';
        }
    });
    
    // Show/hide semantic info
    const semanticInfo = document.getElementById('semantic-info');
    if (semanticInfo) {
        semanticInfo.style.display = strategy === 'semantic' ? 'block' : 'none';
    }
});

// Chunk toggling
function toggleChunk(index) {
    const content = document.getElementById(`chunk-${index}`);
    const icon = document.getElementById(`toggle-${index}`);
    
    content.classList.toggle('collapsed');
    
    if (content.classList.contains('collapsed')) {
        icon.classList.remove('fa-chevron-down');
        icon.classList.add('fa-chevron-up');
    } else {
        icon.classList.remove('fa-chevron-up');
        icon.classList.add('fa-chevron-down');
    }
}

// Copy chunk to clipboard
function copyChunk(index) {
    const chunkContent = document.querySelector(`#chunk-${index} pre`).textContent;
    
    navigator.clipboard.writeText(chunkContent).then(() => {
        // Show success message
        showToast('Chunk copied to clipboard!');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        showToast('Failed to copy chunk', 'error');
    });
}

// Download all chunks
function downloadChunks() {
    const chunks = document.querySelectorAll('.chunk-content pre');
    let content = '';
    
    chunks.forEach((chunk, index) => {
        content += `--- Chunk ${index + 1} ---\n${chunk.textContent}\n\n`;
    });
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chunks.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('Chunks downloaded successfully!');
}

// Show toast notification
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 1050;';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
    toast.style.cssText = 'min-width: 250px; margin-bottom: 10px;';
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.getElementById('toast-container').appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// File validation
document.getElementById('file').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        if (file.type !== 'application/pdf') {
            showToast('Please select a PDF file', 'error');
            this.value = '';
            return;
        }
        
        if (file.size > 10 * 1024 * 1024) { // 10MB
            showToast('File size must be less than 10MB', 'error');
            this.value = '';
            return;
        }
        
        // Show file info
        const fileInfo = document.createElement('div');
        fileInfo.className = 'form-text';
        fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)}MB)`;
        this.parentElement.appendChild(fileInfo);
    }
});

// Form submission loading state
document.getElementById('chunkingForm').addEventListener('submit', function() {
    const submitBtn = this.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Set initial collapsed state for chunks
    const chunks = document.querySelectorAll('.chunk-content');
    chunks.forEach((chunk, index) => {
        if (index > 2) { // Collapse all chunks after the first 3
            chunk.classList.add('collapsed');
            document.getElementById(`toggle-${index}`).classList.remove('fa-chevron-down');
            document.getElementById(`toggle-${index}`).classList.add('fa-chevron-up');
        }
    });
});

// AJAX form submission (optional enhancement)
function submitFormAjax(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
    
    fetch('/api/chunk', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayChunks(data.chunks, data.similarities);
            showToast(`Successfully created ${data.totalChunks} chunks`);
        } else {
            showToast(data.error || 'Error processing PDF', 'error');
        }
    })
    .catch(error => {
        showToast('Network error: ' + error.message, 'error');
    })
    .finally(() => {
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-scissors"></i> Chunk Document';
    });
}

// Display chunks dynamically (for AJAX response)
function displayChunks(chunks, similarities) {
    const resultsContainer = document.querySelector('.col-md-8');
    const isSemantic = document.getElementById('strategy').value === 'semantic';
    
    let chunksHtml = '';
    
    // Add similarity visualization if semantic
    if (isSemantic && similarities && Object.keys(similarities).length > 0) {
        chunksHtml += createSimilarityVisualization(similarities, chunks.length);
    }
    
    chunksHtml += `
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-cubes"></i> Chunks (${chunks.length})
                </h5>
                <div>
                    <button class="btn btn-sm btn-outline-secondary" onclick="downloadChunks()">
                        <i class="fas fa-download"></i> Download All
                    </button>
                </div>
            </div>
            <div class="card-body chunks-container">
    `;
    
    chunks.forEach((chunk, index) => {
        chunksHtml += `
            <div class="chunk-item">
                <div class="chunk-header">
                    <span class="chunk-number">Chunk ${index + 1}</span>
                    <div class="chunk-actions">
                        <span class="text-muted small">${chunk.length} chars</span>
                        <button class="btn btn-sm btn-link" onclick="copyChunk(${index})">
                            <i class="fas fa-copy"></i>
                        </button>
                        <button class="btn btn-sm btn-link" onclick="toggleChunk(${index})">
                            <i class="fas fa-chevron-down" id="toggle-${index}"></i>
                        </button>
                    </div>
                </div>
        `;
        
        // Add similarity info for semantic chunking
        if (isSemantic && similarities) {
            chunksHtml += '<div class="similarity-info">';
            
            if (similarities[index + '_prev']) {
                const simValue = similarities[index + '_prev'];
                const simClass = simValue < 0.5 ? 'low' : simValue < 0.7 ? 'medium' : 'high';
                chunksHtml += `
                    <span class="similarity-badge">
                        <i class="fas fa-arrow-up"></i>
                        Similarity to previous: 
                        <span class="similarity-value ${simClass}">
                            ${simValue.toFixed(3)}
                        </span>
                    </span>
                `;
            }
            
            if (similarities[index + '_next']) {
                const simValue = similarities[index + '_next'];
                const simClass = simValue < 0.5 ? 'low' : simValue < 0.7 ? 'medium' : 'high';
                chunksHtml += `
                    <span class="similarity-badge">
                        <i class="fas fa-arrow-down"></i>
                        Similarity to next: 
                        <span class="similarity-value ${simClass}">
                            ${simValue.toFixed(3)}
                        </span>
                    </span>
                `;
            }
            
            chunksHtml += '</div>';
        }
        
        chunksHtml += `
                <div class="chunk-content" id="chunk-${index}">
                    <pre>${escapeHtml(chunk)}</pre>
                </div>
            </div>
        `;
    });
    
    chunksHtml += `
            </div>
        </div>
    `;
    
    resultsContainer.innerHTML = chunksHtml;
    
    // Initialize similarity chart if semantic
    if (isSemantic && similarities && Object.keys(similarities).length > 0) {
        setTimeout(() => initializeSimilarityChart(similarities, chunks.length), 100);
    }
}

function createSimilarityVisualization(similarities, chunkCount) {
    // Calculate statistics
    let sum = 0, count = 0, min = 1, max = 0;
    
    for (const [key, value] of Object.entries(similarities)) {
        if (key.endsWith('_next')) {
            sum += value;
            count++;
            min = Math.min(min, value);
            max = Math.max(max, value);
        }
    }
    
    const avg = count > 0 ? sum / count : 0;
    
    return `
        <div class="card mb-3">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-chart-line"></i> Cosine Similarity Between Chunks
                </h6>
            </div>
            <div class="card-body">
                <canvas id="similarityChart" height="100"></canvas>
                <div class="mt-3 row text-center">
                    <div class="col-md-4">
                        <div class="stat-box">
                            <h6 class="text-muted">Average Similarity</h6>
                            <h4 class="text-primary">${avg.toFixed(3)}</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-box">
                            <h6 class="text-muted">Min Similarity</h6>
                            <h4 class="text-danger">${(min < 1 ? min : 0).toFixed(3)}</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-box">
                            <h6 class="text-muted">Max Similarity</h6>
                            <h4 class="text-success">${max.toFixed(3)}</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function initializeSimilarityChart(similarities, chunkCount) {
    const ctx = document.getElementById('similarityChart');
    if (!ctx) return;
    
    const labels = [];
    const data = [];
    
    for (let i = 0; i < chunkCount - 1; i++) {
        labels.push(`${i + 1} → ${i + 2}`);
        data.push(similarities[i + '_next'] || 0);
    }
    
    const threshold = parseFloat(document.getElementById('similarityThreshold')?.value || 0.5);
    
    new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Cosine Similarity',
                data: data,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1,
                pointRadius: 5,
                pointHoverRadius: 7
            }, {
                label: 'Threshold',
                data: Array(labels.length).fill(threshold),
                borderColor: 'rgb(255, 99, 132)',
                borderDash: [5, 5],
                pointRadius: 0,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Semantic Similarity Between Adjacent Chunks'
                },
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1,
                    ticks: {
                        stepSize: 0.1
                    },
                    title: {
                        display: true,
                        text: 'Cosine Similarity'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Chunk Transitions'
                    }
                }
            }
        }
    });
	chunksHtml += `
                    <i class="fas fa-cubes"></i> Chunks (${chunks.length})
                </h5>
                <div>
                    <button class="btn btn-sm btn-outline-secondary" onclick="downloadChunks()">
                        <i class="fas fa-download"></i> Download All
                    </button>
                </div>
            </div>
            <div class="card-body chunks-container">
    `;
    
    chunks.forEach((chunk, index) => {
        chunksHtml += `
            <div class="chunk-item">
                <div class="chunk-header">
                    <span class="chunk-number">Chunk ${index + 1}</span>
                    <div class="chunk-actions">
                        <span class="text-muted small">${chunk.length} chars</span>
                        <button class="btn btn-sm btn-link" onclick="copyChunk(${index})">
                            <i class="fas fa-copy"></i>
                        </button>
                        <button class="btn btn-sm btn-link" onclick="toggleChunk(${index})">
                            <i class="fas fa-chevron-down" id="toggle-${index}"></i>
                        </button>
                    </div>
                </div>
                <div class="chunk-content" id="chunk-${index}">
                    <pre>${escapeHtml(chunk)}</pre>
                </div>
            </div>
        `;
    });
    
    chunksHtml += `
            </div>
        </div>
    `;
    
    resultsContainer.innerHTML = chunksHtml;
}

// Utility function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}