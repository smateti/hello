package com.example.pdfchunking.service;

import com.example.pdfchunking.model.ChunkInfo;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SemanticChunkingService {
    
    // Simple embedding using TF-IDF for demonstration
    // In production, you would use real sentence embeddings (e.g., Sentence-BERT)
    private Map<String, Integer> vocabulary = new HashMap<>();
    private int vocabSize = 0;
    
    public List<String> chunkBySemantic(String text, double similarityThreshold, 
                                       int maxChunkSize, int minChunkSize) {
        List<ChunkInfo> chunkInfos = chunkBySemanticWithInfo(text, similarityThreshold, 
                maxChunkSize, minChunkSize);
        return chunkInfos.stream()
                .map(ChunkInfo::getText)
                .collect(Collectors.toList());
    }
    
    public List<ChunkInfo> chunkBySemanticWithInfo(String text, double similarityThreshold,
                                                   int maxChunkSize, int minChunkSize) {
        // Split into sentences
        List<String> sentences = splitIntoSentences(text);
        if (sentences.isEmpty()) {
            return Collections.emptyList();
        }
        
        // Build vocabulary
        buildVocabulary(sentences);
        
        // Get embeddings for each sentence
        List<double[]> embeddings = sentences.stream()
                .map(this::getEmbedding)
                .collect(Collectors.toList());
        
        // Calculate similarities between consecutive sentences
        List<Double> similarities = new ArrayList<>();
        for (int i = 0; i < embeddings.size() - 1; i++) {
            double similarity = cosineSimilarity(embeddings.get(i), embeddings.get(i + 1));
            similarities.add(similarity);
        }
        
        // Find split points where similarity is below threshold
        List<Integer> splitPoints = new ArrayList<>();
        splitPoints.add(0); // Start of text
        
        for (int i = 0; i < similarities.size(); i++) {
            if (similarities.get(i) < similarityThreshold) {
                splitPoints.add(i + 1);
            }
        }
        splitPoints.add(sentences.size()); // End of text
        
        // Create chunks based on split points
        List<ChunkInfo> chunks = new ArrayList<>();
        for (int i = 0; i < splitPoints.size() - 1; i++) {
            int start = splitPoints.get(i);
            int end = splitPoints.get(i + 1);
            
            // Combine sentences into chunk
            StringBuilder chunkText = new StringBuilder();
            int chunkLength = 0;
            
            for (int j = start; j < end; j++) {
                String sentence = sentences.get(j);
                if (chunkLength + sentence.length() > maxChunkSize && chunkLength >= minChunkSize) {
                    // Create chunk if adding this sentence would exceed max size
                    if (chunkText.length() > 0) {
                        ChunkInfo chunk = createChunkInfo(chunkText.toString(), chunks.size(), 
                                embeddings, start, j, similarities);
                        chunks.add(chunk);
                        chunkText = new StringBuilder();
                        chunkLength = 0;
                        start = j;
                    }
                }
                chunkText.append(sentence).append(" ");
                chunkLength += sentence.length() + 1;
            }
            
            // Add remaining text as chunk
            if (chunkText.length() > 0) {
                ChunkInfo chunk = createChunkInfo(chunkText.toString().trim(), chunks.size(),
                        embeddings, start, end, similarities);
                chunks.add(chunk);
            }
        }
        
        return chunks;
    }
    
    private ChunkInfo createChunkInfo(String text, int index, List<double[]> embeddings,
                                     int sentenceStart, int sentenceEnd, List<Double> similarities) {
        // Calculate average embedding for the chunk
        double[] avgEmbedding = calculateAverageEmbedding(embeddings, sentenceStart, sentenceEnd);
        
        ChunkInfo chunk = ChunkInfo.builder()
                .text(text)
                .index(index)
                .embedding(avgEmbedding)
                .build();
        
        // Set similarity to previous chunk
        if (sentenceStart > 0 && sentenceStart - 1 < similarities.size()) {
            chunk.setSimilarityToPrevious(similarities.get(sentenceStart - 1));
        }
        
        // Set similarity to next chunk
        if (sentenceEnd - 1 < similarities.size()) {
            chunk.setSimilarityToNext(similarities.get(sentenceEnd - 1));
        }
        
        return chunk;
    }
    
    private double[] calculateAverageEmbedding(List<double[]> embeddings, int start, int end) {
        if (start >= end || start >= embeddings.size()) {
            return new double[vocabSize];
        }
        
        double[] avg = new double[vocabSize];
        int count = 0;
        
        for (int i = start; i < end && i < embeddings.size(); i++) {
            double[] embedding = embeddings.get(i);
            for (int j = 0; j < embedding.length; j++) {
                avg[j] += embedding[j];
            }
            count++;
        }
        
        if (count > 0) {
            for (int j = 0; j < avg.length; j++) {
                avg[j] /= count;
            }
        }
        
        return avg;
    }
    
    private List<String> splitIntoSentences(String text) {
        // Simple sentence splitting - in production use a proper NLP library
        String[] sentences = text.split("(?<=[.!?])\\s+");
        return Arrays.stream(sentences)
                .filter(s -> !s.trim().isEmpty())
                .collect(Collectors.toList());
    }
    
    private void buildVocabulary(List<String> sentences) {
        vocabulary.clear();
        vocabSize = 0;
        
        for (String sentence : sentences) {
            String[] words = sentence.toLowerCase().split("\\s+");
            for (String word : words) {
                word = word.replaceAll("[^a-zA-Z0-9]", "");
                if (!word.isEmpty() && !vocabulary.containsKey(word)) {
                    vocabulary.put(word, vocabSize++);
                }
            }
        }
    }
    
    private double[] getEmbedding(String sentence) {
        // Simple TF-IDF embedding
        double[] embedding = new double[vocabSize];
        String[] words = sentence.toLowerCase().split("\\s+");
        Map<String, Integer> termFreq = new HashMap<>();
        
        // Calculate term frequency
        for (String word : words) {
            word = word.replaceAll("[^a-zA-Z0-9]", "");
            if (!word.isEmpty() && vocabulary.containsKey(word)) {
                termFreq.put(word, termFreq.getOrDefault(word, 0) + 1);
            }
        }
        
        // Create embedding vector
        for (Map.Entry<String, Integer> entry : termFreq.entrySet()) {
            int index = vocabulary.get(entry.getKey());
            // Simple TF weighting (could add IDF for better results)
            embedding[index] = entry.getValue() / (double) words.length;
        }
        
        return embedding;
    }
    
    private double cosineSimilarity(double[] vec1, double[] vec2) {
        RealVector v1 = new ArrayRealVector(vec1);
        RealVector v2 = new ArrayRealVector(vec2);
        
        double dotProduct = v1.dotProduct(v2);
        double norm1 = v1.getNorm();
        double norm2 = v2.getNorm();
        
        if (norm1 == 0 || norm2 == 0) {
            return 0;
        }
        
        return dotProduct / (norm1 * norm2);
    }
}