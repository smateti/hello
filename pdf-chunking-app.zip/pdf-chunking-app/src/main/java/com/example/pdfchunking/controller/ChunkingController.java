package com.example.pdfchunking.controller;

import com.example.pdfchunking.model.ChunkingRequest;
import com.example.pdfchunking.model.ChunkingResponse;
import com.example.pdfchunking.service.PdfChunkingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class ChunkingController {
    
    private final PdfChunkingService pdfChunkingService;
    
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("strategies", pdfChunkingService.getAvailableStrategies());
        return "index";
    }
    
    @PostMapping("/chunk")
    public String chunkPdf(@RequestParam("file") MultipartFile file,
                          @ModelAttribute ChunkingRequest request,
                          Model model,
                          RedirectAttributes redirectAttributes) {
        
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please select a PDF file");
            return "redirect:/";
        }
        
        if (!file.getContentType().equals("application/pdf")) {
            redirectAttributes.addFlashAttribute("error", "Please upload only PDF files");
            return "redirect:/";
        }
        
        try {
            Map<String, Object> result = pdfChunkingService.chunkPdfWithMetrics(file, request);
            List<String> chunks = (List<String>) result.get("chunks");
            Map<String, Double> similarities = (Map<String, Double>) result.get("similarities");
            System.out.println("similarities="+similarities);
            model.addAttribute("chunks", chunks);
            model.addAttribute("similarities", similarities);
            model.addAttribute("fileName", file.getOriginalFilename());
            model.addAttribute("strategy", request.getStrategy());
            model.addAttribute("totalChunks", chunks.size());
            model.addAttribute("strategies", pdfChunkingService.getAvailableStrategies());
            model.addAttribute("isSemantic", "semantic".equals(request.getStrategy()));
            return "index";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error processing PDF: " + e.getMessage());
            return "redirect:/";
        }
    }
    
    @ResponseBody
    @PostMapping("/api/chunk")
    public ChunkingResponse chunkPdfApi(@RequestParam("file") MultipartFile file,
                                       @ModelAttribute ChunkingRequest request) {
        try {
            Map<String, Object> result = pdfChunkingService.chunkPdfWithMetrics(file, request);
            List<String> chunks = (List<String>) result.get("chunks");
            Map<String, Double> similarities = (Map<String, Double>) result.get("similarities");
            
            return ChunkingResponse.builder()
                    .success(true)
                    .chunks(chunks)
                    .totalChunks(chunks.size())
                    .similarities(similarities)
                    .build();
        } catch (Exception e) {
            return ChunkingResponse.builder()
                    .success(false)
                    .error(e.getMessage())
                    .build();
        }
    }
}