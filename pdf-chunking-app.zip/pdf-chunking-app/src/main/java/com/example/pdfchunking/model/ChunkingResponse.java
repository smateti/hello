package com.example.pdfchunking.model;

import lombok.Builder;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
@Builder
public class ChunkingResponse {
    private boolean success;
    private List<String> chunks;
    private int totalChunks;
    private String error;
    private Map<String, Double> similarities; // For semantic chunking
}