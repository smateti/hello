package com.example.pdfchunking.service;

import com.example.pdfchunking.model.ChunkInfo;
import com.example.pdfchunking.model.ChunkingRequest;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class PdfChunkingService {
    
    @Autowired
    private SemanticChunkingService semanticChunkingService;
    
    public List<String> chunkPdf(MultipartFile file, ChunkingRequest request) throws IOException {
        String text = extractTextFromPdf(file);
        
        switch (request.getStrategy()) {
            case "fixed_size":
                return chunkByFixedSize(text, request.getChunkSize(), request.getChunkOverlap());
            case "sentence":
                return chunkBySentence(text, request.getMaxChunkSize(), request.getMinChunkSize());
            case "paragraph":
                return chunkByParagraph(text, request.getMaxChunkSize(), request.getMinChunkSize());
            case "recursive":
                return chunkRecursive(text, request.getChunkSize(), request.getChunkOverlap());
            case "custom_separator":
                return chunkByCustomSeparator(text, request.getSeparator(), request.isSeparatorRegex());
            case "semantic":
                return semanticChunkingService.chunkBySemantic(text, request.getSimilarityThreshold(), 
                        request.getMaxChunkSize(), request.getMinChunkSize());
            default:
                throw new IllegalArgumentException("Unknown chunking strategy: " + request.getStrategy());
        }
    }
    
    public Map<String, Object> chunkPdfWithMetrics(MultipartFile file, ChunkingRequest request) throws IOException {
        String text = extractTextFromPdf(file);
        Map<String, Object> result = new HashMap<>();
        
        if ("semantic".equals(request.getStrategy())) {
            List<ChunkInfo> chunkInfos = semanticChunkingService.chunkBySemanticWithInfo(
                    text, request.getSimilarityThreshold(), 
                    request.getMaxChunkSize(), request.getMinChunkSize());
            
            List<String> chunks = chunkInfos.stream()
                    .map(ChunkInfo::getText)
                    .collect(Collectors.toList());
            
            Map<String, Double> similarities = new HashMap<>();
            for (int i = 0; i < chunkInfos.size(); i++) {
                ChunkInfo info = chunkInfos.get(i);
                if (info.getSimilarityToPrevious() != null) {
                    similarities.put(i + "_prev", info.getSimilarityToPrevious());
                }
                if (info.getSimilarityToNext() != null) {
                    similarities.put(i + "_next", info.getSimilarityToNext());
                }
            }
            
            result.put("chunks", chunks);
            result.put("similarities", similarities);
        } else {
            result.put("chunks", chunkPdf(file, request));
            result.put("similarities", new HashMap<>());
        }
        
        return result;
    }
    
    private String extractTextFromPdf(MultipartFile file) throws IOException {
        try (PDDocument document = PDDocument.load(file.getInputStream())) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
    }
    
    private List<String> chunkByFixedSize(String text, int chunkSize, int overlap) {
        List<String> chunks = new ArrayList<>();
        int start = 0;
        
        while (start < text.length()) {
            int end = Math.min(start + chunkSize, text.length());
            chunks.add(text.substring(start, end).trim());
            start = end - overlap;
            
            if (start >= text.length() - overlap) {
                break;
            }
        }
        
        return chunks;
    }
    
    private List<String> chunkBySentence(String text, int maxSize, int minSize) {
        List<String> chunks = new ArrayList<>();
        String[] sentences = text.split("(?<=[.!?])\\s+");
        
        StringBuilder currentChunk = new StringBuilder();
        for (String sentence : sentences) {
            if (currentChunk.length() + sentence.length() > maxSize && currentChunk.length() >= minSize) {
                chunks.add(currentChunk.toString().trim());
                currentChunk = new StringBuilder();
            }
            currentChunk.append(sentence).append(" ");
        }
        
        if (currentChunk.length() > 0) {
            chunks.add(currentChunk.toString().trim());
        }
        
        return chunks;
    }
    
    private List<String> chunkByParagraph(String text, int maxSize, int minSize) {
        List<String> chunks = new ArrayList<>();
        String[] paragraphs = text.split("\\n\\n+");
        
        StringBuilder currentChunk = new StringBuilder();
        for (String paragraph : paragraphs) {
            if (currentChunk.length() + paragraph.length() > maxSize && currentChunk.length() >= minSize) {
                chunks.add(currentChunk.toString().trim());
                currentChunk = new StringBuilder();
            }
            currentChunk.append(paragraph).append("\n\n");
        }
        
        if (currentChunk.length() > 0) {
            chunks.add(currentChunk.toString().trim());
        }
        
        return chunks;
    }
    
    private List<String> chunkRecursive(String text, int chunkSize, int overlap) {
        List<String> separators = Arrays.asList("\n\n", "\n", ". ", " ");
        return recursiveChunk(text, separators, 0, chunkSize, overlap);
    }
    
    private List<String> recursiveChunk(String text, List<String> separators, int sepIndex, 
                                       int chunkSize, int overlap) {
        if (text.length() <= chunkSize || sepIndex >= separators.size()) {
            return Collections.singletonList(text);
        }
        
        String separator = separators.get(sepIndex);
        String[] parts = text.split(Pattern.quote(separator));
        
        List<String> chunks = new ArrayList<>();
        StringBuilder currentChunk = new StringBuilder();
        
        for (String part : parts) {
            if (currentChunk.length() + part.length() > chunkSize) {
                if (currentChunk.length() > 0) {
                    chunks.add(currentChunk.toString().trim());
                    currentChunk = new StringBuilder();
                }
                
                if (part.length() > chunkSize) {
                    chunks.addAll(recursiveChunk(part, separators, sepIndex + 1, chunkSize, overlap));
                } else {
                    currentChunk.append(part).append(separator);
                }
            } else {
                currentChunk.append(part).append(separator);
            }
        }
        
        if (currentChunk.length() > 0) {
            chunks.add(currentChunk.toString().trim());
        }
        
        return chunks;
    }
    
    private List<String> chunkByCustomSeparator(String text, String separator, boolean isRegex) {
        String[] parts;
        if (isRegex) {
            parts = text.split(separator);
        } else {
            parts = text.split(Pattern.quote(separator));
        }
        
        return Arrays.asList(parts);
    }
    
    public Map<String, String> getAvailableStrategies() {
        Map<String, String> strategies = new LinkedHashMap<>();
        strategies.put("fixed_size", "Fixed Size - Split text into chunks of fixed character count");
        strategies.put("sentence", "Sentence-based - Split by sentence boundaries");
        strategies.put("paragraph", "Paragraph-based - Split by paragraph boundaries");
        strategies.put("recursive", "Recursive - Recursively split using multiple separators");
        strategies.put("custom_separator", "Custom Separator - Split using custom separator");
        strategies.put("semantic", "Semantic - Split based on semantic similarity between sentences");
        return strategies;
    }
}