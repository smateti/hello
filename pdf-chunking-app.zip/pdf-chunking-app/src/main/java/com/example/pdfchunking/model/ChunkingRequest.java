package com.example.pdfchunking.model;

import lombok.Data;

@Data
public class ChunkingRequest {
    private String strategy = "fixed_size";
    private int chunkSize = 1000;
    private int chunkOverlap = 200;
    private String separator = "\\n\\n";
    private boolean separatorRegex = false;
    private int maxChunkSize = 2000;
    private int minChunkSize = 100;
    private double similarityThreshold = 0.5; // For semantic chunking
}